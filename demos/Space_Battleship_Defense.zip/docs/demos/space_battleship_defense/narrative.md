<<<<<<< HEAD
#
 Space Battleship Defense – Narrative & Lore
=======
# Space Battleship Defense – Narrative & Lore
>>>>>>> 1cb47709b21ebd7aacdb14b4566f7737e5d527ce

## Defend the Earth in an epic space battle against alien invaders

In the far future, Earth has established interstellar travel and colonies across multiple star systems. Humanity’s expansion has not gone unnoticed. Deep in the darkness between the stars, a hostile civilization has been watching, waiting for the right moment to strike. A massive invasion fleet now descends upon the Sol system, intent on eradicating humanity and claiming the Earth for itself.

## The Hikari

Humanity’s last hope is the _Hikari_, an advanced orbital battleship built to defend the Earth from threats beyond our world. The Hikari bristles with heavy laser cannons, particle beam turrets and layered energy shields. Its crew of brave men and women have sworn to hold the line at any cost. As the commander of the Hikari, it is your duty to repel wave after wave of alien attackers, manage the ship’s systems, and protect Earth from orbital bombardment.


## The Enemy

The alien invaders employ an array of saucer‑shaped UFOs in various sizes and capabilities. Small, nimble fighters engage in swift hit‑and‑run attacks meant to wear down the Hikari’s shields. Medium and heavy UFOs pose greater threats with thicker armor and higher firepower. At the end of the assault looms a formidable _boss ship_ leading the invasion. The number and strength of the enemy forces increase over time, challenging even the most seasoned commander.


## Weapons & Projectiles

The Hikari is armed with batteries of laser cannons that fire concentrated blue laser bolts at incoming targets. Your precision and timing will determine whether those bolts find their mark. The aliens respond with seething spheres of volatile plasma – plasma bolts that glow purple and leave trails of incandescent particles in their wake. Each projectile exchange lights up the darkness of space.


## Victory Conditions

To save Earth, you must survive successive attack waves, defeat the boss ships leading each wave, and hold out until reinforcements arrive. Between waves you can reroute power between weapons and shields, and deploy the ship’s superweapon once it is charged. Each victory pushes the alien fleet back; each failure brings humanity closer to extinction.


## Notes for Developers

This narrative document is intended to provide thematic context for the Space Battleship Defense demo in the SDK. The art and model assets correspond to the Hikari battleship, four types of UFO enemies, and their respective projectiles. Feel free to expand upon or adapt this lore to suit your gameplay mechanics or world‑building needs.
