# Space Battleship Defense - Distribution Package

## Overview

This document describes the distribution package for the Space Battleship Defense demo, including how to build and deploy it.

## Package Contents

The Space Battleship Defense distribution package (`Space_Battleship_Defense.zip`) contains:

### Documentation
- **README.md** - Overview and getting started guide
- **design.md** - Complete game design document
- **assets.md** - Asset specifications and requirements
- **telemetry.md** - Telemetry implementation details
- **storyboard_public.md** - Public storyboard and game flow
- **visual_assets_public.md** - Visual assets documentation

### Unity Assets
- **Scripts/** - C# scripts for game logic and audio control
- **Prefabs/** - Unity prefabs for game objects (enemies, battleship, projectiles)
- **Models/** - 3D models and meshes (OBJ and FBX formats)
- **Textures/** - Concept art and texture assets
- **Audio/** - Sound effects and background music
- **VFX/** - Visual effects and materials

### Visual Assets
- SVG thumbnails for all game entities
- Storyboard assets
- UI elements and placeholders

## Package Location

Once deployed, the distribution package is available at:

```
https://raw.githubusercontent.com/BladeWireless/blade-assets/main/demos/Space_Battleship_Defense.zip
```

## Building the Package

To rebuild or update the distribution package, a Python script is available in the repository build tools. The script:

1. Collects all public documentation from `docs/demos/space_battleship_defense/`
2. Includes Unity prototype files from `Assets/SpaceBattleshipDefense/`
3. Adds visual assets from `docs/assets/space_battleship_defense_public/`
4. Creates a structured zip file with all contents organized in a `dist/` directory

### Build Process

The build script performs the following steps:

1. **Documentation Collection**: Copies all public markdown files to `dist/docs/`
2. **Unity Assets**: Copies the complete Unity asset structure to `dist/UnityAssets/`
3. **Visual Assets**: Copies SVG files and storyboard assets to `dist/visual_assets/`
4. **Package README**: Creates a comprehensive README for the package
5. **Archive Creation**: Generates the final ZIP file with compression

### Package Size

- **Approximate Size**: 19-20 MB
- **Compression**: ZIP_DEFLATED method for optimal file size

## Usage

### For Developers

To integrate these assets into your Unity project:

1. Download the package from the URL above
2. Extract the ZIP file
3. Review the documentation in the `dist/docs/` directory
4. Import the Unity assets from `dist/UnityAssets/` into your Unity project
5. Follow the design guidelines in `design.md`

### For Documentation

The documentation files can be used independently:

```bash
unzip Space_Battleship_Defense.zip
cd dist/docs/
# Review markdown files
```

### For Asset Review

Visual assets and thumbnails are available for review:

```bash
unzip Space_Battleship_Defense.zip
cd dist/visual_assets/
# Review SVG files and storyboard
```

## Version Information

- **Created**: 2025-10-15
- **Repository**: BladeWireless/blade-sdk
- **Asset Repository**: BladeWireless/blade-assets
- **Format**: ZIP (DEFLATED)

## Notes

- The package includes placeholder files for some audio assets (marked with `.placeholder` extension)
- All concept art textures are included in PNG format
- 3D models are provided in both OBJ and FBX formats for maximum compatibility
- The package is designed to be self-contained with all necessary documentation

## Support

For questions or issues related to the Space Battleship Defense demo package:
- Review the included documentation files
- Consult the main repository: https://github.com/BladeWireless/blade-sdk
- Check the demos documentation in `docs/demos/space_battleship_defense/`
