# Space Battleship Defense - Documentation Index

**Demo Overview**: A cooperative AR tower defense game for Raku (MiRZA) featuring 60-second defense loops, multiplayer networking, and an epic superweapon finale.

---

## Documentation Structure

### Core Design Documents

1. **[design.md](./design.md)** - Complete Design Specification
   - 60-second defense loop with state diagram
   - Host/client roles and responsibilities  
   - Enemy wave tables, spawn timing, and difficulty curves
   - Network event model (message types, ordering, idempotency, join-in-progress)
   - Desync detection and recovery flows
   - Authoritative server timing and fixed-step scheduling
   - Finale timeline (superweapon sequence, triggers, victory/defeat, retry)
   - Performance budgets (CPU/GPU/draws, platform targets, memory, LOD)

2. **[assets.md](./assets.md)** - Asset Specification
   - Complete asset list (Hikari battleship, UFO enemies, projectiles, VFX/SFX, UI)
   - LOD configurations and poly/texture budgets
   - Integration with asset manifest generation (`scripts/gen_hud_asset_manifest.py`)
   - License mapping (references `licenses/asset_licenses.yaml`)
   - File naming conventions and validation workflow

2a. **[visual_assets_public.md](./visual_assets_public.md)** - Public Visual Asset Gallery
   - Developer-facing visual reference gallery for all assets
   - Asset thumbnails and specifications organized by category
   - Unity import guidelines and workflow tips
   - Bilingual (EN/JA) asset notes and documentation
   - Public-safe content with no confidential details

2b. **[storyboard_public.md](./storyboard_public.md)** - Public Gameplay Storyboard
   - Visual storyboard illustrating the 60-second defense loop
   - Six panels covering lobby, preparation, combat, completion, finale, and victory
   - SDK feature highlights and integration points
   - Bilingual (EN/JA) scene descriptions and technical notes
   - Public-safe content showcasing AR capabilities

3. **[telemetry.md](./telemetry.md)** - Telemetry Specification
   - Telemetry marker taxonomy (`ar_latency_*`, `qos_*`, `gameplay_*`, `desync_*`, `perf_*`)
   - KPIs, dashboards, and alert thresholds
   - Test harness instructions (induce latency/jitter/loss, verify reconciliation)
   - Automated collection workflow and CI integration

### Internal Wiki

4. **[docs/wiki/Space-Battleship-Design.md](../../wiki/Space-Battleship-Design.md)** - Product Brief
   - Product vision, target audience, market positioning
   - Player journey (onboarding, mid-game, finale, replayability)
   - UX beats (visual/audio feedback, minimalist HUD, gaze-based targeting)
   - Content roadmap (v1.0 MVP, v1.1, v2.0)
   - Accessibility and localization considerations
   - Links to all public documentation above

---

## Related Issues & Pull Requests

- **Implementation**: [Issue #185](https://github.com/BladeWireless/blade-sdk/issues/185)
- **Asset Pipeline**: [Issue #198](https://github.com/BladeWireless/blade-sdk/issues/198)
- **Telemetry**: [Issue #199](https://github.com/BladeWireless/blade-sdk/issues/199)
- **Localization**: [Issue #200](https://github.com/BladeWireless/blade-sdk/issues/200)
- **EPIC PR (Design Phase)**: [PR #207](https://github.com/BladeWireless/blade-sdk/pull/207)
- **EPIC PR (Implementation Phase)**: [PR #208](https://github.com/BladeWireless/blade-sdk/pull/208)

---

## Quick Navigation

### For Developers
→ Start with **[design.md](./design.md)** for technical implementation guidance  
→ Reference **[telemetry.md](./telemetry.md)** for instrumentation hooks

### For Artists/Audio Engineers
→ Start with **[visual_assets_public.md](./visual_assets_public.md)** for visual reference gallery  
→ Review **[assets.md](./assets.md)** for detailed technical specifications  
→ Check poly/texture budgets and LOD configurations

### For Product/UX Teams
→ Start with **[docs/wiki/Space-Battleship-Design.md](../../wiki/Space-Battleship-Design.md)** for player experience design  
→ Review accessibility and localization considerations

### For QA/DevOps
→ Start with **[telemetry.md](./telemetry.md)** for test harness and validation procedures  
→ Reference alert thresholds and KPI targets

---

## Documentation Status

| Document                          | Status           | Last Updated | Owner            |
|-----------------------------------|------------------|--------------|------------------|
| design.md                         | ✅ Complete      | 2025-01-15   | Engineering      |
| assets.md                         | ✅ Complete      | 2025-01-15   | Art/Engineering  |
| telemetry.md                      | ✅ Complete      | 2025-01-15   | DevOps/QA        |
| docs/wiki/Space-Battleship-Design.md | ✅ Complete   | 2025-01-15   | Product          |

**All documentation is ready for handoff to implementation (Issue #185).**

---

## Cross-References

### Referenced Architecture Patterns
- **Wave System**: [samples/unity/CityDefense/Docs/ARCHITECTURE.md](../../../samples/unity/CityDefense/Docs/ARCHITECTURE.md)
- **Multiplayer Networking**: [samples/unity/ArenaMultiplayer/Docs/NETWORKING_REPORT.md](../../../samples/unity/ArenaMultiplayer/Docs/NETWORKING_REPORT.md)

### Referenced Pipeline Documentation
- **Asset Pipeline Overview**: [docs/asset_pipeline_overview.md](../../asset_pipeline_overview.md)
- **Telemetry Integration Guide**: [docs/TELEMETRY_INTEGRATION.md](../../TELEMETRY_INTEGRATION.md)
- **Performance Status**: [PERFORMANCE_STATUS.md](../../../PERFORMANCE_STATUS.md)

---

**Questions or Feedback?**  
Open an issue referencing `#185` (implementation) or contact the project team via Slack `#space-battleship-dev`.
