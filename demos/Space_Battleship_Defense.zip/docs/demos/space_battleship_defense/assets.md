


**Related**: [Design Specification](./design.md)  
**Asset Pipeline**: [Issue #198](https://github.com/BladeWireless/blade-sdk/issues/198), [docs/asset_pipeline_overview.md](../../asset_pipeline_overview.md)  
**License Mapping**: `licenses/asset_licenses.yaml`

---

## Overview

This document defines all visual, audio, and UI assets required for Space Battleship Defense, including poly/texture budgets, LOD configurations, and integration with the automated asset manifest system.

---

## Asset Categories

### 1. Characters & Vehicles

#### Hikari Battleship (Hero Asset)

**Primary Model**:
- **ID**: `hikari_battleship_main`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Hikari/Hikari_LOD0.fbx`
- **Poly Count**: 8,000 triangles
- **Textures**:
  - `Hikari_Albedo.png` - 2048x2048, sRGB, ETC2 compressed
  - `Hikari_Normal.png` - 2048x2048, Linear, ETC2 compressed
  - `Hikari_MetallicSmoothness.png` - 2048x2048, Linear, ETC2
  - `Hikari_Emissive.png` - 1024x1024, sRGB, ETC2
- **Materials**: 3 (hull, windows, engines)
- **Animations**: None (static, VFX only)
- **LOD Levels**: 3 (LOD0, LOD1, LOD2)

**LOD1 Model**:
- **ID**: `hikari_battleship_lod1`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Hikari/Hikari_LOD1.fbx`
- **Poly Count**: 4,000 triangles
- **Textures**: 1024x1024 (half-resolution)

**LOD2 Model**:
- **ID**: `hikari_battleship_lod2`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Hikari/Hikari_LOD2.fbx`
- **Poly Count**: 2,000 triangles
- **Textures**: 512x512 (quarter-resolution)

**Damage States** (Optional for v1.0):
- `Hikari_Damaged_Albedo.png` - Overlay texture for damaged state
- `Hikari_Destroyed_Albedo.png` - Heavily damaged variant

---

#### UFO Enemies

##### Small UFO
- **ID**: `ufo_small`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Small_LOD0.fbx`
- **Poly Count**: 1,000 triangles
- **Textures**:
  - `UFO_Small_Albedo.png` - 512x512, sRGB, ETC2
  - `UFO_Small_Normal.png` - 512x512, Linear, ETC2
  - `UFO_Small_Emissive.png` - 256x256, sRGB, ETC2
- **Materials**: 1
- **Animations**: Rotate (shader-based), Wobble
- **LOD Levels**: 3

##### Medium UFO
- **ID**: `ufo_medium`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Medium_LOD0.fbx`
- **Poly Count**: 1,500 triangles
- **Textures**: 512x512 (same as Small UFO, recolored variant)
- **Materials**: 1
- **LOD Levels**: 3

##### Heavy UFO
- **ID**: `ufo_heavy`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Heavy_LOD0.fbx`
- **Poly Count**: 2,500 triangles
- **Textures**:
  - `UFO_Heavy_Albedo.png` - 1024x1024, sRGB, ETC2
  - `UFO_Heavy_Normal.png` - 1024x1024, Linear, ETC2
  - `UFO_Heavy_Emissive.png` - 512x512, sRGB, ETC2
- **Materials**: 2 (body, armor plates)
- **LOD Levels**: 3

##### Boss UFO
- **ID**: `ufo_boss`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Boss_LOD0.fbx`
- **Poly Count**: 4,000 triangles
- **Textures**:
  - `UFO_Boss_Albedo.png` - 1024x1024, sRGB, ETC2
  - `UFO_Boss_Normal.png` - 1024x1024, Linear, ETC2
  - `UFO_Boss_Emissive.png` - 512x512, sRGB, ETC2
  - `UFO_Boss_Detail.png` - 512x512, sRGB, ETC2
- **Materials**: 2 (body, details)
- **Animations**: Rotate, Pulse (shader-based)
- **LOD Levels**: 3

**LOD Guidelines for All UFOs**:
- **LOD0**: Full detail (0-15m)
- **LOD1**: 50% poly reduction (15-40m)
- **LOD2**: Billboard sprite (40m+), 200 tris quad with alpha

---

### 2. Projectiles & Weapons

#### Player Projectile
- **ID**: `projectile_player_laser`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Projectiles/Laser_Bolt.fbx`
- **Poly Count**: 20 triangles (elongated capsule)
- **Textures**:
  - `Laser_Emissive.png` - 128x128, sRGB, uncompressed
- **Materials**: 1 (additive shader)
- **Instanced**: Yes (up to 200 simultaneous)

#### Enemy Projectile
- **ID**: `projectile_enemy_plasma`
- **Path**: `Assets/SpaceBattleshipDefense/Models/Projectiles/Plasma_Bolt.fbx`
- **Poly Count**: 20 triangles
- **Textures**:
  - `Plasma_Emissive.png` - 128x128, sRGB, uncompressed
- **Materials**: 1 (additive shader, recolor for enemy types)

---

### 3. Visual Effects (VFX)

#### Explosion Effects

##### Small Explosion (Enemy Death)
- **ID**: `vfx_explosion_small`
- **Path**: `Assets/SpaceBattleshipDefense/VFX/Explosion_Small.prefab`
- **Particle Count**: 50-100 particles
- **Textures**:
  - `Explosion_Atlas.png` - 512x512 (4x4 flipbook), sRGB, ETC2
- **Duration**: 1.5s
- **Memory**: ~500 KB

##### Large Explosion (Boss Death, Finale)
- **ID**: `vfx_explosion_large`
- **Path**: `Assets/SpaceBattleshipDefense/VFX/Explosion_Large.prefab`
- **Particle Count**: 200-300 particles
- **Textures**:
  - `Explosion_Large_Atlas.png` - 1024x1024 (4x4 flipbook), sRGB, ETC2
- **Duration**: 3s
- **Memory**: ~1 MB

#### Hit Effects
- **ID**: `vfx_hit_enemy`
- **Path**: `Assets/SpaceBattleshipDefense/VFX/Hit_Spark.prefab`
- **Particle Count**: 10-20 particles
- **Textures**: `Hit_Spark.png` - 128x128, sRGB, ETC2
- **Duration**: 0.5s

#### Weapon Fire Effects
- **ID**: `vfx_muzzle_flash`
- **Path**: `Assets/SpaceBattleshipDefense/VFX/Muzzle_Flash.prefab`
- **Particle Count**: 5-10 particles
- **Textures**: `Muzzle_Flash.png` - 256x256, sRGB, ETC2
- **Duration**: 0.2s

#### Superweapon Effects

##### Charging Effect
- **ID**: `vfx_superweapon_charge`
- **Path**: `Assets/SpaceBattleshipDefense/VFX/Superweapon_Charge.prefab`
- **Particle Count**: 500 particles (continuous)
- **Textures**:
  - `Energy_Particle.png` - 256x256, sRGB, ETC2
- **Duration**: 10s (during finale sequence)
- **Memory**: ~2 MB

##### Beam Effect
- **ID**: `vfx_superweapon_beam`
- **Path**: `Assets/SpaceBattleshipDefense/VFX/Superweapon_Beam.prefab`
- **Poly Count**: 100 triangles (beam mesh)
- **Textures**:
  - `Beam_Gradient.png` - 512x128, sRGB, uncompressed
- **Duration**: 2s (finale impact)
- **Memory**: ~500 KB

---

### 4. User Interface (UI)

#### HUD Elements

##### Health Bar
- **ID**: `ui_health_bar`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Textures/HealthBar.png`
- **Size**: 512x64, sRGB, uncompressed (alpha channel)
- **Components**: Background, fill, border
- **Dynamic**: Health fill updates per frame

##### Wave Counter
- **ID**: `ui_wave_counter`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Textures/WaveCounter.png`
- **Size**: 256x256, sRGB, uncompressed
- **Font**: Embedded in texture (bitmap font)
- **Dynamic**: Wave number updated between waves

##### Reticle
- **ID**: `ui_reticle`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Textures/Reticle.png`
- **Size**: 128x128, sRGB, uncompressed (alpha)
- **Variants**: Default, Locked (targeting enemy)

##### Score Display
- **ID**: `ui_score_display`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Prefabs/ScoreDisplay.prefab`
- **Font**: `Assets/SpaceBattleshipDefense/UI/Fonts/RobotoMono_Regular.ttf`
- **Size**: 24pt (scalable vector font)
- **Dynamic**: Score updates on enemy kill

#### Menu Screens

##### Title Screen
- **ID**: `ui_title_screen`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Screens/TitleScreen.prefab`
- **Background**: `TitleBG.png` - 1920x1080, sRGB, ETC2
- **Buttons**: `Button_Atlas.png` - 1024x256 (sprites), sRGB, ETC2

##### Victory Screen
- **ID**: `ui_victory_screen`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Screens/VictoryScreen.prefab`
- **Background**: `VictoryBG.png` - 1920x1080, sRGB, ETC2
- **Decorations**: Trophy icon, fireworks VFX

##### Defeat Screen
- **ID**: `ui_defeat_screen`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Screens/DefeatScreen.prefab`
- **Background**: `DefeatBG.png` - 1920x1080, sRGB, ETC2
- **Decorations**: Broken battleship silhouette

#### Fonts
- **ID**: `font_roboto_mono`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Fonts/RobotoMono_Regular.ttf`
- **License**: Apache 2.0 (open source)
- **Usage**: Score, timer, wave counter

- **ID**: `font_orbitron_bold`
- **Path**: `Assets/SpaceBattleshipDefense/UI/Fonts/Orbitron_Bold.ttf`
- **License**: SIL Open Font License
- **Usage**: Title screen, headers

---

### 5. Audio (SFX)

#### Weapon Sounds

##### Player Laser Fire
- **ID**: `sfx_laser_fire`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Laser_Fire.ogg`
- **Format**: Ogg Vorbis, 48 kHz, mono
- **Duration**: 0.3s
- **Size**: ~15 KB

##### Enemy Plasma Fire
- **ID**: `sfx_plasma_fire`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Plasma_Fire.ogg`
- **Format**: Ogg Vorbis, 48 kHz, mono
- **Duration**: 0.4s
- **Size**: ~18 KB

#### Explosion Sounds

##### Small Explosion
- **ID**: `sfx_explosion_small`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Explosion_Small.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 1.2s
- **Size**: ~40 KB

##### Large Explosion
- **ID**: `sfx_explosion_large`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Explosion_Large.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 2.5s
- **Size**: ~80 KB

#### Impact Sounds
- **ID**: `sfx_hit_enemy`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Hit_Enemy.ogg`
- **Format**: Ogg Vorbis, 48 kHz, mono
- **Duration**: 0.2s
- **Size**: ~10 KB

#### UI Sounds
- **ID**: `sfx_button_click`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Button_Click.ogg`
- **Format**: Ogg Vorbis, 48 kHz, mono
- **Duration**: 0.1s
- **Size**: ~5 KB

- **ID**: `sfx_wave_complete`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Wave_Complete.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 2s
- **Size**: ~60 KB

#### Superweapon Sounds
- **ID**: `sfx_superweapon_charge`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Superweapon_Charge.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 10s (looping)
- **Size**: ~250 KB

- **ID**: `sfx_superweapon_fire`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/Superweapon_Fire.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 3s
- **Size**: ~100 KB

---

### 6. Audio (Music)

#### Combat Music
- **ID**: `music_combat`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/Music/Combat_Loop.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 120s (looping)
- **Size**: ~3 MB
- **License**: Royalty-free or commissioned

#### Finale Music
- **ID**: `music_finale`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/Music/Finale_Theme.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 25s (one-shot)
- **Size**: ~600 KB

#### Victory Music
- **ID**: `music_victory`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/Music/Victory_Fanfare.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 10s (one-shot)
- **Size**: ~250 KB

#### Defeat Music
- **ID**: `music_defeat`
- **Path**: `Assets/SpaceBattleshipDefense/Audio/Music/Defeat_Stinger.ogg`
- **Format**: Ogg Vorbis, 48 kHz, stereo
- **Duration**: 5s (one-shot)
- **Size**: ~120 KB

---

## Asset Budget Summary

| Category           | Count | Poly Budget | Texture Budget | Memory Budget |
|--------------------|-------|-------------|----------------|---------------|
| Battleship         | 1     | 8,000       | 8 MB           | 10 MB         |
| Enemies            | 4     | 9,000       | 4 MB           | 6 MB          |
| Projectiles        | 2     | 40          | 256 KB         | 500 KB        |
| VFX                | 10    | 1,000       | 4 MB           | 6 MB          |
| UI                 | 15    | 0           | 8 MB           | 10 MB         |
| Audio (SFX)        | 15    | -           | -              | 1 MB          |
| Audio (Music)      | 4     | -           | -              | 4 MB          |
| **Total**          | **51**| **18,040**  | **~24 MB**     | **~38 MB**    |

**Note**: All texture sizes are post-compression (ETC2/ASTC). Uncompressed equivalents would be 4-6x larger.

---

## LOD Configuration

### Automatic LOD Switching

**Distance Thresholds**:
- **LOD0 → LOD1**: 15 meters
- **LOD1 → LOD2**: 40 meters
- **LOD2 → Culled**: 60 meters

**Hysteresis**:
- Add ±2 meters hysteresis to prevent popping
- Example: Switch from LOD0 to LOD1 at 15m, but switch back at 13m

**LOD Transition Method**:
- **Smooth Cross-Fade**: 1-second blend between LODs
- **Dither Alpha**: Use temporal dithering for GPU-efficient blending

### Per-Asset LOD Tables

#### Hikari Battleship
| LOD   | Distance Range | Poly Count | Texture Size | Memory  |
|-------|----------------|------------|--------------|---------|
| LOD0  | 0-20m          | 8,000      | 2048x2048    | 8 MB    |
| LOD1  | 20-50m         | 4,000      | 1024x1024    | 2 MB    |
| LOD2  | 50m+           | 2,000      | 512x512      | 512 KB  |

#### UFO Enemies (All Types)
| LOD   | Distance Range | Poly Count | Texture Size | Memory  |
|-------|----------------|------------|--------------|---------|
| LOD0  | 0-15m          | 1,000-4,000| 512x512-1K   | 500 KB-2 MB |
| LOD1  | 15-40m         | 500-2,000  | 256x256-512  | 128 KB-512 KB |
| LOD2  | 40-60m         | 200 (billboard) | 256x256 | 128 KB  |

---

## Integration with Asset Manifest

### Manifest Generation

Use the automated pipeline to generate asset manifests:

```bash
python3 scripts/gen_hud_asset_manifest.py \
  --input Assets/SpaceBattleshipDefense \
  --output manifests/space_battleship_defense_manifest.yaml
```

**Output Format** (`manifests/space_battleship_defense_manifest.yaml`):

```yaml
manifest_version: "1.0"
generated_date: "2025-01-15"
demo: "space_battleship_defense"
items:
  - id: hikari_battleship_main
    path: Assets/SpaceBattleshipDefense/Models/Hikari/Hikari_LOD0.fbx
    type: model
    size_bytes: 2456789
    sha256: abc123...
    license_placeholder: "See licenses/asset_licenses.yaml"
    metadata:
      poly_count: 8000
      lod_level: 0
      texture_resolution: 2048
  
  - id: hikari_albedo
    path: Assets/SpaceBattleshipDefense/Models/Hikari/Hikari_Albedo.png
    type: texture
    size_bytes: 4194304
    sha256: def456...
    license_placeholder: "See licenses/asset_licenses.yaml"
    metadata:
      resolution: "2048x2048"
      format: "ETC2_sRGB"
      compression: "ETC2"
  
  # ... (all other assets)
```

### License Mapping

**File**: `licenses/asset_licenses.yaml`

```yaml
space_battleship_defense:
  models:
    hikari_battleship:
      license: "BladeWireless Internal - Copyright 2025"
      author: "Art Team Alpha"
      source: "Original Work"
      
    ufo_enemies:
      license: "Creative Commons CC0 (Modified)"
      author: "Original by Poly Pizza, modified by Blade Art Team"
      source: "https://poly.pizza/m/ufo-pack"
      modifications: "Re-textured, LOD levels added"
  
  textures:
    all_textures:
      license: "BladeWireless Internal"
      author: "Art Team Alpha"
      source: "Substance Designer procedural generation"
  
  audio:
    sfx:
      license: "Freesound.org CC0 / CC-BY (see individual files)"
      source: "Freesound.org"
      credits: "See AUDIO_CREDITS.txt"
    
    music:
      license: "Licensed from Epidemic Sound"
      provider: "Epidemic Sound"
      license_id: "ES-2025-001234"
      expiry: "2026-12-31"
  
  fonts:
    roboto_mono:
      license: "Apache License 2.0"
      source: "Google Fonts"
      url: "https://fonts.google.com/specimen/Roboto+Mono"
    
    orbitron:
      license: "SIL Open Font License 1.1"
      source: "Google Fonts"
      url: "https://fonts.google.com/specimen/Orbitron"
```

---

## File Naming Conventions

### General Rules
- **Snake_case** for asset IDs: `hikari_battleship_main`
- **PascalCase** for files: `Hikari_Battleship_LOD0.fbx`
- **Descriptive names**: Include asset type and variant
- **Version suffixes**: Avoid (use source control for versioning)

### Prefixes
- Models: No prefix, just descriptive name
- Textures: Type suffix (`_Albedo`, `_Normal`, `_Emissive`)
- Audio: Category prefix (`SFX_`, `Music_`)
- UI: `UI_` prefix

### LOD Suffixes
- Models: `_LOD0`, `_LOD1`, `_LOD2`
- Textures: Include resolution in folder structure, not filename

### Examples
✅ **Good**:
- `Hikari_Battleship_LOD0.fbx`
- `UFO_Small_Albedo.png`
- `SFX_Laser_Fire.ogg`
- `UI_HealthBar.png`

❌ **Bad**:
- `model_v3_final.fbx` (vague, version in name)
- `texture1.png` (non-descriptive)
- `laser.ogg` (missing category prefix)

---

## Validation Workflow

### Pre-Commit Checks

Run asset validation before committing:

```bash
# Validate all assets in demo directory
python3 scripts/validate_asset_licenses.py \
  --manifest manifests/space_battleship_defense_manifest.yaml \
  --licenses licenses/asset_licenses.yaml

# Check poly budgets
python3 scripts/check_poly_budgets.py \
  --manifest manifests/space_battleship_defense_manifest.yaml \
  --budget 20000

# Verify texture compression
python3 scripts/verify_texture_compression.py \
  --path Assets/SpaceBattleshipDefense/Models \
  --format ETC2
```

### CI Pipeline Integration

The asset pipeline runs automatically in CI (`.github/workflows/asset_pipeline.yml`):

1. **On Push/PR**: Scan `Assets/SpaceBattleshipDefense/`
2. **Generate Manifest**: Auto-update manifest with hashes
3. **Validate Licenses**: Fail if any asset lacks license mapping
4. **Check Budgets**: Warn if poly/texture budgets exceeded
5. **Upload Artifact**: Publish manifest as workflow artifact

---

## Asset Delivery

### Build-Time Asset Processing

**Unity Build Pipeline**:
1. Import all assets from `Assets/SpaceBattleshipDefense/`
2. Apply texture compression (ETC2 for Android, ASTC for iOS)
3. Generate LOD meshes if missing
4. Compress audio (Vorbis at quality 0.7)
5. Strip unused assets (rely on asset references)

**Build Sizes**:
- **Android APK**: ~60 MB (with compression)
- **iOS IPA**: ~65 MB (ASTC textures larger)
- **Streaming Assets**: ~10 MB (music streamed separately)

### Runtime Asset Loading

**Lazy Loading** (Performance Optimization):
- Load UI assets on startup (~5 MB)
- Load game assets on "Start Game" (~30 MB)
- Stream music during gameplay (no upfront load)

**Memory Management**:
- Unload unused assets after game end (free ~30 MB)
- Keep UI assets resident (avoid reload stutter)

---

## Current Asset Status

### Directory Structure

All Space Battleship Defense assets are organized under `Assets/SpaceBattleshipDefense/`:

```
Assets/SpaceBattleshipDefense/
├── Models/
│   ├── Hikari/
│   │   ├── HikariBattleship_LOD0.fbx
│   │   ├── HikariBattleship_LOD1.fbx
│   │   ├── Hikari_Albedo.png
│   │   ├── Hikari_Normal.png
│   │   ├── Hikari_Metallic.png
│   │   └── Hikari_Roughness.png
│   └── Enemies/
│       ├── UFO_Small_LOD0.fbx
│       ├── UFO_Small_Albedo.png
│       ├── UFO_Small_Normal.png
│       ├── UFO_Medium_LOD0.fbx
│       ├── UFO_Medium_Albedo.png
│       ├── UFO_Heavy_LOD0.fbx
│       ├── UFO_Heavy_Albedo.png
│       ├── UFO_Boss_LOD0.fbx
│       └── UFO_Boss_Albedo.png
├── Audio/
│   └── SFX/
│       ├── laser.wav
│       ├── spawn.wav
│       ├── impact.wav
│       ├── finale_charge.wav
│       └── finale_release.wav
├── VFX/
│   └── Projectiles/
│       ├── Beam.mat
│       ├── MuzzleFlash.mat
│       └── Explosion.mat
└── Prefabs/
    ├── HikariBattleship.prefab
    ├── EnemyUFO_Small.prefab
    └── Projectile.prefab
```

### Manifest Generation

The asset manifest is automatically generated using:

```bash
python3 scripts/gen_space_battleship_asset_manifest.py
```

This generates `manifests/space_battleship_defense_manifest.yaml` with:
- Asset IDs and paths
- SHA256 hashes for integrity verification
- File sizes and types
- License references

### License Mapping

All assets are mapped in `licenses/asset_licenses.yaml` under the following categories:
- **Hikari Battleship**: Models and textures for the hero ship
- **UFO Enemies**: Models and textures for all enemy types
- **VFX Materials**: Beam, explosion, and muzzle flash effects
- **Audio SFX**: Weapon sounds and enemy spawn effects
- **Prefabs**: Game object prefabs for instantiation

All assets use `Internal-BladeWireless` license attribution.

### Notes

**Current Asset State**: The assets currently in the repository are placeholder files (text stubs) for structural validation. Actual PNG textures, OBJ/FBX models, and audio files should be provided by the art and audio teams.

**Next Steps**:
1. Replace placeholder files with actual production assets
2. Run manifest generator to update SHA256 hashes
3. Validate asset licenses and poly counts
4. Test asset loading in Unity

---

## References

- **Design Specification**: [design.md](./design.md)
- **Asset Pipeline Overview**: [docs/asset_pipeline_overview.md](../../asset_pipeline_overview.md)
- **Asset Pipeline Issue**: [#198](https://github.com/BladeWireless/blade-sdk/issues/198)
- **Telemetry Spec**: [telemetry.md](./telemetry.md)
- **Licenses**: `licenses/asset_licenses.yaml`

-## Additional Placeholder Assets (2025-10-11)

The following assets were added as concept art and low-poly placeholders for the Space Battleship Defense demo on October 11, 2025. They reside under `Assets/SpaceBattleshipDefense/Textures` and `Assets/SpaceBattleshipDefense/Models` respectively.

### Concept Art

| Asset | PNG filename | Description |
| --- | --- | --- |
| Hikari Battleship | HikariBattleship_Concept.png | Concept art of the Hikari battleship hero asset. |
| UFO Small | UFOSmall_Concept.png | Concept art of the small UFO enemy. |
| UFO Medium | UFOMedium_Concept.png | Concept art of the medium UFO enemy. |
| UFO Heavy | UFOHeavy_Concept.png | Concept art of the heavy UFO enemy. |
| UFO Boss | UFOBoss_Concept.png | Concept art of the boss UFO enemy. |
| Laser Bolt | LaserBolt_Concept.png | Concept art of the player's laser bolt projectile. |
| Plasma Bolt | PlasmaBolt_Concept.png | Concept art of the enemy’s plasma bolt projectile. |

### Placeholder Models

| Asset | OBJ filename | Description |
| --- | --- | --- |
| Hikari Battleship | HikariBattleship.obj | Low-poly placeholder model for the Hikari battleship. |
| UFO Small | UFOSmall.obj | Low-poly placeholder model for the small UFO enemy. |
| UFO Medium | UFOMedium.obj | Low-poly placeholder model for the medium UFO enemy. |
| UFO Heavy | UFOHeavy.obj | Low-poly placeholder model for the heavy UFO enemy. |
| UFO Boss | UFOBoss.obj | Low-poly placeholder model for the boss UFO enemy. |
| Laser Bolt | LaserBolt.obj | Low-poly placeholder model for the player's laser bolt. |
| Plasma Bolt | PlasmaBolt.obj | Low-poly placeholder model for the enemy’s plasma bolt. |

**Note:** These concept art images and placeholder models were added via the GitHub.dev editor, which automatically uploads binary assets using Git LFS. They serve only as temporary placeholders and will be replaced with final assets during production.

-




**Document Version**: 1.0  
**Last Updated**: 2025-01-15  
**Status**: Ready for Asset Production
## Additional Placeholder Assets (2025-10-11)

To support early prototyping of the Space Battleship Defense demo, we created concept art images and low‑poly placeholder models for each key element. These assets are temporary placeholders and will be replaced by fully art‑directed assets later in production.

### Concept Art

| Asset | File | Description |
|------|------|-------------|
| Hikari Battleship | `HikariBattleship_Concept.png` | High‑quality concept art of the hero Hikari battleship. |
| Small UFO | `UFOSmall_Concept.png` | Concept art of the small saucer‑shaped enemy UFO. |
| Medium UFO | `UFOMedium_Concept.png` | Concept art of the medium‑sized enemy UFO. |
| Heavy UFO | `UFOHeavy_Concept.png` | Concept art of the heavy armored enemy UFO. |
| Boss UFO | `UFOBoss_Concept.png` | Concept art of the massive boss UFO. |
| Player Laser Bolt | `LaserBolt_Concept.png` | Concept art of the player’s laser bolt projectile. |
| Enemy Plasma Bolt | `PlasmaBolt_Concept.png` | Concept art of the enemy plasma bolt projectile. |

### Placeholder Models

| Asset | File | Description |
|------|------|-------------|
| Hikari Battleship | `HikariBattleship.obj` | Low‑poly placeholder model for the Hikari Battleship. |
| Small UFO | `UFOSmall.obj` | Low‑poly placeholder model for the small UFO. |
| Medium UFO | `UFOMedium.obj` | Low‑poly placeholder model for the medium UFO. |
| Heavy UFO | `UFOHeavy.obj` | Low‑poly placeholder model for the heavy UFO. |
| Boss UFO | `UFOBoss.obj` | Low‑poly placeholder model for the boss UFO. |
| Player Laser Bolt | `LaserBolt.obj` | Low‑poly placeholder model for the player’s laser bolt. |
| Enemy Plasma Bolt | `PlasmaBolt.obj` | Low‑poly placeholder model for the enemy’s plasma bolt. |

**Note:** These concept art images and placeholder models were added via the GitHub.dev editor, which automatically uploads binary assets using Git LFS. They serve only as temporary placeholders and will be replaced with final assets during production.



### LOD and Texture Consistency Workflow

Maintaining visual continuity across levels of detail (LOD) models and their associated textures is essential for a cohesive user experience. When adding or updating models and textures for **Space Battleship Defense**, follow this workflow:

1. **Inspect LOD0:** For each asset, start by opening the highest fidelity model (LOD0) and its textures. Note the silhouette, proportions, and key texture details (albedo, normal, emissive, metallic, roughness, etc.).
2. **Validate or recreate LOD1:** Open the existing LOD1 model. Check that its geometry matches the silhouette and major shapes of LOD0. Compare its textures to the LOD0 versions. If the mesh or textures look inconsistent (e.g., different patterns or colors), recreate the LOD1 by simplifying the LOD0 mesh while preserving overall shape and derive the textures by down‑sampling or simplifying the LOD0 maps.
3. **Generate LOD2:** Create the LOD2 model by further reducing the polygon count of the validated LOD1 while preserving the silhouette and proportions. Again, derive the textures from the higher‑detail maps to ensure consistent colors, patterns and emissive regions.
4. **Repeat for each asset:** Apply this process to every asset in the missing assets list (e.g., Hikari battleship, UFO enemy types, projectiles, and VFX). Always ensure that color palettes and emissive patterns remain consistent across all LOD levels and that textures follow the same layout (UVs) as the base model.
5. **Document and update:** After generating consistent LODs and textures, update `docs/demos/space_battleship_defense/assets.md` with entries for each new asset, including file names, poly counts, and texture maps.

This workflow ensures a coherent look and feel across all LOD models and texture maps, reducing visual popping and preserving the integrity of the game's aesthetic.