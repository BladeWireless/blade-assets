# Space Battleship Defense Visual Asset Gallery

**Public Gallery**: For developer-facing visual asset reference with thumbnails and specifications, see **[visual_assets_public.md](./visual_assets_public.md)**.

The full internal visual asset gallery and art style guide are maintained in the internal `blade-docs` repository under `docs/demos/space_battleship_defense/`. Please refer to that repository for high-resolution concept art, production assets, and internal development notes.

For public-safe content including Unity import guidelines, asset specifications, and visual reference gallery, see [visual_assets_public.md](./visual_assets_public.md).
