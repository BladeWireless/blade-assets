# Space Battleship Defense - Public Gameplay Storyboard
# スペース・バトルシップ・ディフェンス - 公開ゲームプレイストーリーボード

**Status**: Public Documentation  
**Related Documents**: [Design Specification](./design.md) | [Asset Specification](./assets.md) | [Visual Asset Gallery](./visual_assets_public.md) | [README](./README.md)  
**Implementation**: [Issue #185](https://github.com/BladeWireless/blade-sdk/issues/185) - Space Battleship Defense Implementation  
**Visual Gallery**: [Issue #270](https://github.com/BladeWireless/blade-sdk/issues/270) - Visual Asset Gallery and Storyboard

---

## Overview | 概要

This document provides a public-facing gameplay storyboard for the Space Battleship Defense AR demo. It illustrates the 60-second defense loop through six key panels, highlighting SDK capabilities and AR features without revealing confidential technical details or proprietary information.

このドキュメントは、Space Battleship Defense ARデモの公開ゲームプレイストーリーボードを提供します。6つの主要なパネルを通じて60秒の防衛ループを示し、機密技術情報や独自情報を明かすことなくSDK機能とAR機能を強調します。

**Purpose**: Help developers understand the gameplay flow, state transitions, and SDK integration points for building similar AR defense games.

**目的**: 開発者がゲームプレイフロー、状態遷移、および類似のAR防衛ゲームを構築するためのSDK統合ポイントを理解するのを支援すること。

---

## Table of Contents | 目次

- [Panel 1: Lobby Wait](#panel-1-lobby-wait--パネル1待機ロビー)
- [Panel 2: Wave Prepare](#panel-2-wave-prepare--パネル2ウェーブ準備)
- [Panel 3: Wave Active](#panel-3-wave-active--パネル3ウェーブアクティブ)
- [Panel 4: Wave Complete](#panel-4-wave-complete--パネル4ウェーブ完了)
- [Panel 5: Finale Trigger & Sequence](#panel-5-finale-trigger--sequence--パネル5フィナーレトリガーとシーケンス)
- [Panel 6: Victory/Defeat](#panel-6-victorydefeat--パネル6勝利敗北)
- [SDK Features Demonstrated](#sdk-features-demonstrated--実証されたsdk機能)
- [Technical Notes](#technical-notes--技術ノート)
- [Cross-References](#cross-references--クロスリファレンス)

---

## Panel 1: Lobby Wait | パネル1：待機ロビー

<img src="../../assets/space_battleship_defense_public/storyboard/panel_1_lobby.svg" alt="Panel 1: Lobby Wait - Players join and prepare for battle" width="600"/>

### Scene Description | シーン説明

**EN**: Players join the multiplayer lobby and wait for the host to start the game. The Hikari battleship appears as a holographic AR anchor in the center of the play space. Players can position themselves around the battleship and see other connected players represented by avatar indicators.

**JA**: プレイヤーはマルチプレイヤーロビーに参加し、ホストがゲームを開始するのを待ちます。ヒカリ戦艦は、プレイスペースの中央にホログラフィックARアンカーとして表示されます。プレイヤーは戦艦の周りに自分自身を配置し、アバターインジケーターで表される他の接続されたプレイヤーを見ることができます。

### SDK Features | SDK機能

- **Spatial Anchors**: Battleship positioned using AR world anchors for stable placement
- **Network Replication**: Player join events synchronized across all clients
- **Session Management**: Host/client role assignment and lobby state management
- **Avatar Indicators**: Simple visual representation of connected players
- **Input Handling**: Gesture-based UI interaction for lobby controls

**JA機能**:
- **空間アンカー**: 安定した配置のためにARワールドアンカーを使用して配置された戦艦
- **ネットワークレプリケーション**: すべてのクライアント間で同期されたプレイヤー参加イベント
- **セッション管理**: ホスト/クライアントの役割割り当てとロビー状態管理
- **アバターインジケーター**: 接続されたプレイヤーのシンプルなビジュアル表現
- **入力処理**: ロビーコントロールのためのジェスチャーベースのUI操作

### Technical Notes | 技術ノート

- Maximum 4 players per session
- Host has authority over game start trigger
- Lobby uses low-bandwidth state sync (< 1KB/s per client)
- AR anchor persists across session lifecycle

**JA技術ノート**:
- セッションあたり最大4プレイヤー
- ホストはゲーム開始トリガーに対して権限を持つ
- ロビーは低帯域幅状態同期を使用（クライアントあたり<1KB/s）
- ARアンカーはセッションライフサイクル全体にわたって持続

### Transition | 遷移

When the host activates "Start Game", all clients transition to **Wave Prepare** state with synchronized countdown.

ホストが「ゲーム開始」を有効にすると、すべてのクライアントは同期されたカウントダウンで**ウェーブ準備**状態に遷移します。

---

## Panel 2: Wave Prepare | パネル2：ウェーブ準備

<img src="../../assets/space_battleship_defense_public/storyboard/panel_2_prepare.svg" alt="Panel 2: Wave Prepare - Countdown and positioning" width="600"/>

### Scene Description | シーン説明

**EN**: A 3-second countdown begins before the first enemy wave. Players see a large countdown timer overlay and can make final positioning adjustments. The battleship's defensive systems activate with glowing lights and UI elements appearing in AR space.

**JA**: 最初の敵ウェーブの前に3秒のカウントダウンが始まります。プレイヤーは大きなカウントダウンタイマーオーバーレイを見て、最終的な位置調整を行うことができます。戦艦の防御システムは、光るライトとARスペースに表示されるUI要素で活性化されます。

### SDK Features | SDK機能

- **Synchronized Timers**: Fixed-timestep countdown synchronized across all clients
- **HUD Overlays**: World-space UI elements for countdown and wave info
- **Audio Cues**: Spatial audio countdown beeps positioned at battleship location
- **State Synchronization**: All clients enter combat-ready state simultaneously
- **Visual Effects**: Activation animations for battleship systems

**JA機能**:
- **同期タイマー**: すべてのクライアント間で同期された固定タイムステップカウントダウン
- **HUDオーバーレイ**: カウントダウンとウェーブ情報のためのワールドスペースUI要素
- **オーディオキュー**: 戦艦の位置に配置された空間オーディオカウントダウンビープ音
- **状態同期**: すべてのクライアントが同時に戦闘準備状態に入る
- **視覚効果**: 戦艦システムのアクティベーションアニメーション

### Technical Notes | 技術ノート

- Fixed 3-second countdown (configurable in design spec)
- Countdown synchronized via authoritative server time
- UI scales based on player distance from battleship
- Audio spatially positioned for immersive AR experience

**JA技術ノート**:
- 固定3秒カウントダウン（設計仕様で構成可能）
- 信頼できるサーバー時間を介して同期されたカウントダウン
- プレイヤーと戦艦の距離に基づいてスケールするUI
- 没入型ARエクスペリエンスのために空間的に配置されたオーディオ

### Transition | 遷移

When countdown reaches zero, the game enters **Wave Active** state and enemy spawning begins immediately.

カウントダウンがゼロに達すると、ゲームは**ウェーブアクティブ**状態に入り、敵のスポーンが即座に開始されます。

---

## Panel 3: Wave Active | パネル3：ウェーブアクティブ

<img src="../../assets/space_battleship_defense_public/storyboard/panel_3_active.svg" alt="Panel 3: Wave Active - Combat in progress!" width="600"/>

### Scene Description | シーン説明

**EN**: Intense combat action! UFO enemies spawn around the perimeter and advance toward the Hikari battleship. Players use gaze-targeting to lock onto enemies and trigger laser fire. The HUD displays health bar, wave progress (enemies remaining), and score. Explosions and hit effects provide satisfying visual feedback.

**JA**: 激しい戦闘アクション！UFO敵が周囲にスポーンし、ヒカリ戦艦に向かって前進します。プレイヤーは視線ターゲティングを使用して敵をロックオンし、レーザー射撃をトリガーします。HUDにはヘルスバー、ウェーブの進行状況（残りの敵）、スコアが表示されます。爆発とヒットエフェクトは満足のいく視覚的フィードバックを提供します。

### SDK Features | SDK機能

- **Gaze-Based Targeting**: Eye/head tracking for enemy lock-on (no controllers required)
- **Dynamic LOD**: Enemy models switch detail levels based on distance from player
- **Network Replication**: Enemy positions, health, and destruction events synced across clients
- **Particle Systems**: GPU-accelerated VFX for explosions and weapon fire
- **Performance Optimization**: Instanced rendering for multiple enemies (up to 50 simultaneous)
- **Telemetry & QoS**: Real-time latency and packet loss monitoring

**JA機能**:
- **視線ベースのターゲティング**: 敵のロックオンのための目/頭の追跡（コントローラーは不要）
- **動的LOD**: プレイヤーからの距離に基づいて詳細レベルを切り替える敵モデル
- **ネットワークレプリケーション**: クライアント間で同期された敵の位置、ヘルス、破壊イベント
- **パーティクルシステム**: 爆発と武器発射のためのGPUアクセラレーションVFX
- **パフォーマンス最適化**: 複数の敵のためのインスタンスレンダリング（最大50同時）
- **テレメトリとQoS**: リアルタイムのレイテンシとパケットロス監視

### Technical Notes | 技術ノート

- 60-second wave duration with three escalating spawn peaks
- Server-authoritative hit detection with client-side prediction for responsive feel
- Enemy behavior uses simple AI pathfinding toward battleship
- Health depletion triggers wave failure state
- Frame budget: 60 FPS target on Raku hardware

**JA技術ノート**:
- 3つのエスカレートするスポーンピークを持つ60秒のウェーブ期間
- レスポンシブな感覚のためのクライアント側予測を備えたサーバー権限ヒット検出
- 敵の行動は戦艦に向かう単純なAIパスファインディングを使用
- ヘルスの枯渇はウェーブ失敗状態をトリガー
- フレーム予算：Rakuハードウェアで60 FPSターゲット

### Transition | 遷移

When all enemies are destroyed (or 60 seconds elapse), the game transitions to **Wave Complete** state with victory fanfare.

すべての敵が破壊されると（または60秒が経過すると）、ゲームは勝利ファンファーレで**ウェーブ完了**状態に遷移します。

---

## Panel 4: Wave Complete | パネル4：ウェーブ完了

<img src="../../assets/space_battleship_defense_public/storyboard/panel_4_complete.svg" alt="Panel 4: Wave Complete - Wave cleared!" width="600"/>

### Scene Description | シーン説明

**EN**: Victory celebration! The wave complete screen displays statistics: enemies destroyed, health remaining, time taken, and points earned. Players have a brief moment to catch their breath before the next wave begins. The battleship remains intact and ready for the next challenge.

**JA**: 勝利の祝賀！ウェーブ完了画面には統計が表示されます：破壊された敵、残りのヘルス、かかった時間、獲得したポイント。プレイヤーは次のウェーブが始まる前に息をつく短い瞬間を持ちます。戦艦は無傷で次のチャレンジの準備ができています。

### SDK Features | SDK機能

- **State Persistence**: Wave progress and score saved across wave transitions
- **UI Animations**: Smooth transitions for stats display and celebration effects
- **Audio Integration**: Victory music and sound effects triggered on wave completion
- **Leaderboard Integration**: (Optional) Score submission to online leaderboards
- **Session Management**: Automatic progression to next wave or finale sequence

**JA機能**:
- **状態の永続性**: ウェーブ遷移全体で保存されたウェーブの進行状況とスコア
- **UIアニメーション**: 統計表示と祝賀エフェクトのためのスムーズな遷移
- **オーディオ統合**: ウェーブ完了時にトリガーされる勝利音楽と効果音
- **リーダーボード統合**: （オプション）オンラインリーダーボードへのスコア提出
- **セッション管理**: 次のウェーブまたはフィナーレシーケンスへの自動進行

### Technical Notes | 技術ノート

- Inter-wave break duration: ~5 seconds (configurable)
- Score calculation: enemies destroyed × difficulty multiplier + time bonus
- Health regeneration between waves (optional design choice)
- After 5 waves, progression to finale sequence instead of next wave

**JA技術ノート**:
- ウェーブ間休憩期間：約5秒（構成可能）
- スコア計算：破壊された敵×難易度乗数+時間ボーナス
- ウェーブ間のヘルス再生（オプションのデザイン選択）
- 5ウェーブ後、次のウェーブの代わりにフィナーレシーケンスへの進行

### Transition | 遷移

After the celebration period, if fewer than 5 waves completed, return to **Wave Prepare** for next wave. If 5 waves completed, proceed to **Finale Trigger & Sequence**.

祝賀期間の後、5ウェーブ未満が完了した場合は、次のウェーブのために**ウェーブ準備**に戻ります。5ウェーブが完了した場合は、**フィナーレトリガーとシーケンス**に進みます。

---

## Panel 5: Finale Trigger & Sequence | パネル5：フィナーレトリガーとシーケンス

<img src="../../assets/space_battleship_defense_public/storyboard/panel_5_finale.svg" alt="Panel 5: Finale Sequence - Superweapon charging!" width="600"/>

### Scene Description | シーン説明

**EN**: The ultimate showdown! A massive boss UFO appears, and the Hikari battleship activates its superweapon. Players see an epic charging sequence with dramatic visual effects: energy particles converging on the battleship, glowing intensifying, and a charge meter filling. The superweapon fires a massive beam that obliterates the boss in a spectacular explosion.

**JA**: 究極の対決！巨大なボスUFOが現れ、ヒカリ戦艦がスーパーウェポンを起動します。プレイヤーは劇的な視覚効果を伴う壮大なチャージシーケンスを見ます：戦艦に収束するエネルギーパーティクル、強化される輝き、そして満たされるチャージメーター。スーパーウェポンは壮観な爆発でボスを消滅させる巨大なビームを発射します。

### SDK Features | SDK機能

- **Scripted Sequences**: Cinematic timeline with precise timing for dramatic effect
- **Advanced VFX**: Complex particle systems for superweapon charge and beam
- **Camera Control**: Automatic viewpoint adjustment for optimal cinematic framing
- **Synchronized Events**: All clients experience finale simultaneously with synchronized timing
- **Audio-Visual Sync**: Music, sound effects, and visuals perfectly timed together
- **Telemetry Events**: Finale trigger, completion, and outcome tracked for analytics

**JA機能**:
- **スクリプト化されたシーケンス**: 劇的な効果のための精密なタイミングを持つシネマティックタイムライン
- **高度なVFX**: スーパーウェポンのチャージとビームのための複雑なパーティクルシステム
- **カメラコントロール**: 最適なシネマティックフレーミングのための自動視点調整
- **同期イベント**: すべてのクライアントが同期されたタイミングでフィナーレを同時に体験
- **オーディオビジュアル同期**: 音楽、効果音、ビジュアルが完璧にタイミング合わせ
- **テレメトリイベント**: 分析のために追跡されたフィナーレトリガー、完了、結果

### Technical Notes | 技術ノート

- Finale sequence duration: ~15 seconds (charge: 10s, beam: 2s, explosion: 3s)
- Requires high-performance mode for maximum visual fidelity
- Boss UFO has significantly higher poly count (within budget)
- Superweapon beam uses mesh-based rendering with scrolling textures
- Post-processing effects: bloom, chromatic aberration, screen shake

**JA技術ノート**:
- フィナーレシーケンス期間：約15秒（チャージ：10秒、ビーム：2秒、爆発：3秒）
- 最大の視覚的忠実度のための高性能モードが必要
- ボスUFOは大幅に高いポリゴンカウントを持つ（予算内）
- スーパーウェポンビームはスクロールテクスチャを備えたメッシュベースのレンダリングを使用
- ポストプロセッシングエフェクト：ブルーム、色収差、スクリーンシェイク

### Transition | 遷移

After the boss explosion, the game transitions to **Victory/Defeat** state displaying final results and options to retry or return to lobby.

ボスの爆発後、ゲームは最終結果とリトライまたはロビーに戻るオプションを表示する**勝利/敗北**状態に遷移します。

---

## Panel 6: Victory/Defeat | パネル6：勝利/敗北

<img src="../../assets/space_battleship_defense_public/storyboard/panel_6_outcome.svg" alt="Panel 6: Victory - Mission accomplished!" width="600"/>

### Scene Description | シーン説明

**EN**: Mission complete! The victory screen displays comprehensive statistics: total score, waves cleared, time elapsed, accuracy percentage, and rank/grade. The intact Hikari battleship remains visible in AR space as a symbol of success. Players can choose to replay the mission or return to the lobby to start a new session with different players.

**JA**: ミッション完了！勝利画面には包括的な統計が表示されます：合計スコア、クリアされたウェーブ、経過時間、精度パーセンテージ、ランク/グレード。無傷のヒカリ戦艦は成功の象徴としてARスペースに表示され続けます。プレイヤーはミッションをリプレイするか、ロビーに戻って異なるプレイヤーと新しいセッションを開始することを選択できます。

### SDK Features | SDK機能

- **Statistics Tracking**: Comprehensive gameplay metrics collected throughout session
- **Persistent State**: Score and progress saved to local storage and/or cloud
- **Social Features**: (Optional) Share results with friends or post to social media
- **Session Management**: Clean teardown of multiplayer session and AR state
- **Navigation**: Return to lobby or replay with same/different players

**JA機能**:
- **統計追跡**: セッション全体で収集された包括的なゲームプレイメトリック
- **永続状態**: ローカルストレージおよび/またはクラウドに保存されたスコアと進行状況
- **ソーシャル機能**: （オプション）友達と結果を共有するか、ソーシャルメディアに投稿
- **セッション管理**: マルチプレイヤーセッションとAR状態のクリーンな解体
- **ナビゲーション**: ロビーに戻るか、同じ/異なるプレイヤーでリプレイ

### Technical Notes | 技術ノート

- Victory condition: Survive all 5 waves + defeat boss with health > 0%
- Defeat condition: Battleship health reaches 0% at any point
- Grade calculation based on score, time, accuracy, and health remaining
- Session data sent to analytics backend for game balancing insights
- Graceful disconnection handling if players drop during finale

**JA技術ノート**:
- 勝利条件：すべての5ウェーブを生き残る+ヘルス>0%でボスを倒す
- 敗北条件：戦艦のヘルスがいつでも0%に達する
- スコア、時間、精度、残りのヘルスに基づくグレード計算
- ゲームバランシングの洞察のために分析バックエンドに送信されたセッションデータ
- フィナーレ中にプレイヤーがドロップした場合の優雅な切断処理

### Transition | 遷移

Players can select "Play Again" (returns to **Lobby Wait**) or "Exit" (closes AR session and returns to main menu).

プレイヤーは「もう一度プレイ」（**待機ロビー**に戻る）または「終了」（ARセッションを閉じてメインメニューに戻る）を選択できます。

---

## SDK Features Demonstrated | 実証されたSDK機能

### Core AR Features | コアAR機能

- **Spatial Anchors**: Persistent world-locked positioning for game objects
- **Gaze Tracking**: Eye/head-based targeting without controller input
- **World-Space UI**: HUD elements positioned in AR space relative to game objects
- **Spatial Audio**: 3D positional audio for immersive sound effects

### Multiplayer & Networking | マルチプレイヤーとネットワーキング

- **Session Management**: Host/client architecture with lobby system
- **State Synchronization**: Real-time replication of game state across clients
- **Authoritative Server**: Server-side validation for gameplay integrity
- **Fixed-Timestep Simulation**: Deterministic gameplay synchronized across network

### Performance & Optimization | パフォーマンスと最適化

- **Dynamic LOD**: Distance-based level-of-detail switching for models
- **Instanced Rendering**: Efficient rendering of multiple identical enemies
- **GPU Particles**: Hardware-accelerated particle systems for VFX
- **Memory Management**: Efficient asset loading and unloading

### Telemetry & Quality of Service | テレメトリとサービス品質

- **Latency Monitoring**: Real-time network performance tracking
- **Packet Loss Detection**: QoS metrics for connection quality
- **Analytics Events**: Gameplay events logged for balancing and debugging
- **Performance Profiling**: Frame rate and resource usage monitoring

---

## Technical Notes | 技術ノート

### Performance Targets | パフォーマンスターゲット

- **Frame Rate**: 60 FPS sustained on Raku hardware
- **Latency**: < 50ms network round-trip time for smooth multiplayer
- **Memory Budget**: < 2GB total for app + assets
- **Battery Impact**: < 20% battery drain per 10-minute session

### Platform Compatibility | プラットフォーム互換性

- **Primary Platform**: Raku (MiRZA) AR glasses
- **Secondary Platforms**: Mobile AR (ARKit/ARCore) with adjusted performance budgets
- **Input Methods**: Gaze tracking (primary), touch gestures (fallback), voice commands (optional)

### Public-Safe Content Notice | 公開安全コンテンツ通知

This storyboard is sanitized for public distribution. It does not include:
- Proprietary hardware specifications or performance benchmarks
- Confidential partnership details or internal project names
- Unreleased SDK features or experimental capabilities
- Internal development tools or debugging interfaces

このストーリーボードは公開配布用にサニタイズされています。以下は含まれていません：
- 独自のハードウェア仕様またはパフォーマンスベンチマーク
- 機密パートナーシップの詳細または内部プロジェクト名
- 未公開のSDK機能または実験的な機能
- 内部開発ツールまたはデバッグインターフェース

---

## Cross-References | クロスリファレンス

### Related Documentation | 関連ドキュメント

- **[Design Specification](./design.md)** - Complete technical design including 60-second loop, networking model, and performance budgets
- **[Asset Specification](./assets.md)** - Detailed asset requirements, LOD tables, and manifest integration
- **[Visual Asset Gallery](./visual_assets_public.md)** - Visual reference gallery with thumbnails and Unity import guidelines
- **[README](./README.md)** - Documentation index and quick navigation

### SDK Documentation | SDKドキュメント

- **[SDK Documentation Hub](../../SDK_V02_DOCUMENTATION_HUB.md)** - Main SDK documentation portal
- **[10-Minute Quickstart](../../10_MINUTE_QUICKSTART.md)** - Quick introduction to SDK capabilities
- **[API Reference](../../API_REFERENCE_V02.md)** - Detailed API documentation

### Implementation Resources | 実装リソース

- **[Issue #185](https://github.com/BladeWireless/blade-sdk/issues/185)** - Space Battleship Defense implementation tracking
- **[Issue #270](https://github.com/BladeWireless/blade-sdk/issues/270)** - Visual Asset Gallery and Storyboard
- **[Asset Pipeline Overview](../../asset_pipeline_overview.md)** - Asset workflow and manifest generation

---

## Questions & Feedback | 質問とフィードバック

**For technical questions**: Open an issue referencing `#185` (implementation) or `#270` (visual gallery)  
**For asset requests**: Refer to [assets.md](./assets.md) and [visual_assets_public.md](./visual_assets_public.md)  
**For SDK support**: See [SDK Documentation Hub](../../SDK_V02_DOCUMENTATION_HUB.md)

**技術的な質問について**: `#185`（実装）または`#270`（ビジュアルギャラリー）を参照して問題を開く  
**アセットリクエストについて**: [assets.md](./assets.md)と[visual_assets_public.md](./visual_assets_public.md)を参照  
**SDKサポートについて**: [SDKドキュメンテーションハブ](../../SDK_V02_DOCUMENTATION_HUB.md)を参照

---

**Document Version**: 1.0  
**Last Updated**: 2024-10-13  
**Status**: Public Documentation - Ready for External Distribution
