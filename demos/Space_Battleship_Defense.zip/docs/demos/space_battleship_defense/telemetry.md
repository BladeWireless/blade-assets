# Space Battleship Defense - Telemetry Specification

**Related**: [Design Specification](./design.md), [Assets Specification](./assets.md)  
**Telemetry Integration**: [Issue #199](https://github.com/BladeWireless/blade-sdk/issues/199), [docs/TELEMETRY_INTEGRATION.md](../../TELEMETRY_INTEGRATION.md)  
**Performance Status**: [PERFORMANCE_STATUS.md](../../../PERFORMANCE_STATUS.md)

---

## Overview

This document defines the telemetry instrumentation, KPI tracking, and quality assurance metrics for Space Battleship Defense. It provides actionable guidance for performance monitoring, network QoS validation, and user experience optimization.

---

## Telemetry Marker Taxonomy

### Category: AR Latency (`ar_latency_*`)

Tracks end-to-end latency components from the Raku T-001 breakdown.

#### `ar_latency_total`
- **Description**: Total motion-to-photon latency
- **Unit**: Milliseconds (ms)
- **Target**: <100 ms (p95), <80 ms (p50)
- **Sample Rate**: 30 Hz (every frame on AR glasses)
- **Logging**: Continuous during gameplay

**JSON Schema**:
```json
{
  "marker": "ar_latency_total",
  "timestamp_ms": 1234567890,
  "value_ms": 78.5,
  "percentile": "p50",
  "frame_number": 12345
}
```

#### `ar_latency_tracking`
- **Description**: Head tracking latency (IMU processing)
- **Unit**: Milliseconds (ms)
- **Target**: <5 ms
- **Sample Rate**: 30 Hz

#### `ar_latency_rendering`
- **Description**: GPU rendering time per frame
- **Unit**: Milliseconds (ms)
- **Target**: <16 ms (60 FPS), <33 ms (30 FPS)
- **Sample Rate**: 30 Hz

#### `ar_latency_display`
- **Description**: Display scanout latency
- **Unit**: Milliseconds (ms)
- **Target**: <10 ms
- **Sample Rate**: 30 Hz

#### `ar_latency_network_sync`
- **Description**: Network synchronization latency (host → AR glasses)
- **Unit**: Milliseconds (ms)
- **Target**: <50 ms (p95), <30 ms (p50)
- **Sample Rate**: 20 Hz (server tick rate)

**JSON Schema**:
```json
{
  "marker": "ar_latency_network_sync",
  "timestamp_ms": 1234567890,
  "value_ms": 28.3,
  "player_id": 42,
  "packet_type": "WORLD_STATE",
  "packet_sequence": 5678
}
```

---

### Category: Network QoS (`qos_*`)

Tracks network quality metrics for multiplayer synchronization.

#### `qos_packet_loss`
- **Description**: Packet loss percentage
- **Unit**: Percentage (%)
- **Target**: <1% (critical), <3% (acceptable)
- **Sample Rate**: 1 Hz (rolling 10-second window)
- **Thresholds**:
  - **Green**: <1%
  - **Yellow**: 1-3%
  - **Red**: >3%

**JSON Schema**:
```json
{
  "marker": "qos_packet_loss",
  "timestamp_ms": 1234567890,
  "value_percent": 1.2,
  "window_seconds": 10,
  "packets_sent": 200,
  "packets_lost": 2
}
```

#### `qos_jitter`
- **Description**: Network jitter (variance in latency)
- **Unit**: Milliseconds (ms)
- **Target**: <10 ms (stable), <20 ms (acceptable)
- **Sample Rate**: 1 Hz
- **Calculation**: Standard deviation of last 100 packet latencies

**JSON Schema**:
```json
{
  "marker": "qos_jitter",
  "timestamp_ms": 1234567890,
  "value_ms": 8.5,
  "window_size": 100,
  "min_latency_ms": 25.0,
  "max_latency_ms": 45.0
}
```

#### `qos_rtt`
- **Description**: Round-trip time (ping)
- **Unit**: Milliseconds (ms)
- **Target**: <50 ms (excellent), <100 ms (good), <150 ms (playable)
- **Sample Rate**: 1 Hz

**JSON Schema**:
```json
{
  "marker": "qos_rtt",
  "timestamp_ms": 1234567890,
  "value_ms": 42.0,
  "source": "client_3",
  "destination": "server"
}
```

#### `qos_bandwidth_usage`
- **Description**: Network bandwidth consumption
- **Unit**: Kilobytes per second (KB/s)
- **Target**: <100 KB/s per client
- **Sample Rate**: 1 Hz

**JSON Schema**:
```json
{
  "marker": "qos_bandwidth_usage",
  "timestamp_ms": 1234567890,
  "value_kbps": 75.5,
  "direction": "upstream",
  "protocol": "UDP"
}
```

---

### Category: Gameplay Metrics (`gameplay_*`)

Tracks game-specific performance and user experience.

#### `gameplay_wave_completion_time`
- **Description**: Time taken to complete a wave
- **Unit**: Seconds (s)
- **Target**: <60s (per design), <90s for Easy mode
- **Sample Rate**: Per wave

**JSON Schema**:
```json
{
  "marker": "gameplay_wave_completion_time",
  "timestamp_ms": 1234567890,
  "value_s": 58.3,
  "wave_number": 5,
  "difficulty": "normal",
  "enemies_total": 36,
  "enemies_killed": 36
}
```

#### `gameplay_accuracy`
- **Description**: Player weapon accuracy (hits / shots)
- **Unit**: Percentage (%)
- **Target**: >40% (average player)
- **Sample Rate**: Per wave

**JSON Schema**:
```json
{
  "marker": "gameplay_accuracy",
  "timestamp_ms": 1234567890,
  "value_percent": 62.5,
  "shots_fired": 120,
  "shots_hit": 75,
  "player_id": 42
}
```

#### `gameplay_battleship_health_over_time`
- **Description**: Battleship health progression during wave
- **Unit**: Health points (HP)
- **Target**: >0 at wave end (victory)
- **Sample Rate**: 1 Hz during wave

**JSON Schema**:
```json
{
  "marker": "gameplay_battleship_health_over_time",
  "timestamp_ms": 1234567890,
  "value_hp": 350,
  "wave_number": 5,
  "time_in_wave_s": 42.5
}
```

#### `gameplay_enemy_spawn_timing`
- **Description**: Actual vs. expected enemy spawn timing
- **Unit**: Milliseconds (ms) offset
- **Target**: <100 ms deviation
- **Sample Rate**: Per enemy spawn

**JSON Schema**:
```json
{
  "marker": "gameplay_enemy_spawn_timing",
  "timestamp_ms": 1234567890,
  "value_offset_ms": 45.0,
  "expected_spawn_time_ms": 1234567000,
  "actual_spawn_time_ms": 1234567045,
  "enemy_id": 9876
}
```

---

### Category: Desync Detection (`desync_*`)

Tracks state synchronization errors and recovery.

#### `desync_detected`
- **Description**: Client-server state hash mismatch
- **Unit**: Boolean event
- **Target**: 0 occurrences per session
- **Sample Rate**: Event-driven

**JSON Schema**:
```json
{
  "marker": "desync_detected",
  "timestamp_ms": 1234567890,
  "frame_number": 12345,
  "player_id": 42,
  "client_hash": "0xABCD1234",
  "server_hash": "0xABCD5678",
  "drift_magnitude": 8.5,
  "recovery_method": "hard"
}
```

#### `desync_recovery_time`
- **Description**: Time taken to recover from desync
- **Unit**: Milliseconds (ms)
- **Target**: <1000 ms (soft recovery), <3000 ms (hard recovery)
- **Sample Rate**: Event-driven

**JSON Schema**:
```json
{
  "marker": "desync_recovery_time",
  "timestamp_ms": 1234567890,
  "value_ms": 750.0,
  "recovery_method": "soft",
  "frame_number": 12345
}
```

---

### Category: Performance (`perf_*`)

Tracks CPU/GPU/memory performance metrics.

#### `perf_frame_time`
- **Description**: Total frame processing time
- **Unit**: Milliseconds (ms)
- **Target**: <16 ms (60 FPS), <33 ms (30 FPS)
- **Sample Rate**: Every frame

**JSON Schema**:
```json
{
  "marker": "perf_frame_time",
  "timestamp_ms": 1234567890,
  "value_ms": 14.2,
  "frame_number": 12345,
  "cpu_time_ms": 8.5,
  "gpu_time_ms": 5.7
}
```

#### `perf_draw_calls`
- **Description**: Number of GPU draw calls per frame
- **Unit**: Count
- **Target**: <100 (per design)
- **Sample Rate**: Every 10 frames (performance sampling)

**JSON Schema**:
```json
{
  "marker": "perf_draw_calls",
  "timestamp_ms": 1234567890,
  "value_count": 87,
  "frame_number": 12345,
  "triangles_rendered": 68000
}
```

#### `perf_memory_usage`
- **Description**: Runtime memory consumption
- **Unit**: Megabytes (MB)
- **Target**: <150 MB (per design budget)
- **Sample Rate**: Every 5 seconds

**JSON Schema**:
```json
{
  "marker": "perf_memory_usage",
  "timestamp_ms": 1234567890,
  "value_mb": 132.5,
  "category": "game_logic",
  "heap_allocated_mb": 85.0,
  "native_allocated_mb": 47.5
}
```

---

## KPIs and Dashboards

### Critical KPIs

| KPI                          | Target         | Threshold    | Priority |
|------------------------------|----------------|--------------|----------|
| **AR Latency (p95)**         | <100 ms        | <120 ms      | P0       |
| **Network RTT (p95)**        | <100 ms        | <150 ms      | P0       |
| **Packet Loss**              | <1%            | <3%          | P0       |
| **Frame Rate (p50)**         | 60 FPS         | 30 FPS       | P1       |
| **Wave Completion Rate**     | >80%           | >60%         | P1       |
| **Player Accuracy**          | >40%           | >25%         | P2       |
| **Desync Events per Session**| 0              | <2           | P0       |

### Dashboard Sections

#### 1. Network Health Dashboard
- **URL**: `reports/dashboards/network_health.html`
- **Panels**:
  - RTT over time (line chart)
  - Packet loss heatmap (per player)
  - Jitter distribution (histogram)
  - Bandwidth usage (stacked area chart)
- **Refresh**: Real-time (1 Hz)

#### 2. AR Performance Dashboard
- **URL**: `reports/dashboards/ar_performance.html`
- **Panels**:
  - Total latency breakdown (stacked bar)
  - Frame time distribution (histogram)
  - GPU/CPU utilization (dual-axis line chart)
  - Memory usage over time (line chart)
- **Refresh**: 10 seconds

#### 3. Gameplay Analytics Dashboard
- **URL**: `reports/dashboards/gameplay_analytics.html`
- **Panels**:
  - Wave completion rates (bar chart per wave)
  - Player accuracy distribution (box plot)
  - Battleship health progression (multi-line chart)
  - Enemy spawn timing accuracy (scatter plot)
- **Refresh**: Post-session (batch processing)

### Dashboard Implementation

**Technology Stack**:
- **Backend**: Python (Flask) + JSON data files
- **Frontend**: HTML + Chart.js or Plotly
- **Data Source**: `metrics/raw/*.json` (see PERFORMANCE_STATUS.md)

**Example Dashboard Query**:
```python
# scripts/generate_dashboard.py
import json
import pandas as pd

def load_telemetry_data(marker_type):
    data = []
    for file in glob.glob(f"metrics/raw/{marker_type}_*.json"):
        with open(file) as f:
            data.append(json.load(f))
    return pd.DataFrame(data)

# Load AR latency data
latency_data = load_telemetry_data("ar_latency_total")

# Calculate p50, p95
p50 = latency_data['value_ms'].quantile(0.5)
p95 = latency_data['value_ms'].quantile(0.95)

# Render to dashboard
dashboard = {
    "ar_latency": {
        "p50_ms": p50,
        "p95_ms": p95,
        "target_p95_ms": 100,
        "status": "green" if p95 < 100 else "red"
    }
}
```

---

## Alert Thresholds

### Critical Alerts (P0 - Immediate Action)

| Alert                     | Condition                      | Action                          |
|---------------------------|--------------------------------|---------------------------------|
| **High AR Latency**       | p95 > 120 ms for 30s          | Alert on-call engineer          |
| **Network Desync Storm**  | >5 desync events in 60s       | Auto-restart game session       |
| **Server Overload**       | Tick time > 80 ms for 10 ticks| Throttle player connections     |
| **Client Crash Rate**     | >10% players crash in 5 min   | Disable demo, rollback          |

### Warning Alerts (P1 - Monitor)

| Alert                     | Condition                      | Action                          |
|---------------------------|--------------------------------|---------------------------------|
| **Degraded Network**      | Packet loss 1-3% for 60s      | Log warning, notify ops         |
| **Low Frame Rate**        | FPS <40 for 30s               | Log performance, notify QA      |
| **High Jitter**           | Jitter >20 ms for 60s         | Log network instability         |

### Informational Alerts (P2 - Trend Analysis)

| Alert                     | Condition                      | Action                          |
|---------------------------|--------------------------------|---------------------------------|
| **Player Accuracy Low**   | Avg accuracy <30% per session | Review difficulty tuning        |
| **Wave Timeout Frequent** | >20% waves timeout            | Adjust spawn rate               |

### Alert Delivery

**Channels**:
- **Critical (P0)**: PagerDuty, Slack #incidents, Email
- **Warning (P1)**: Slack #alerts
- **Informational (P2)**: Daily digest email

**Escalation Policy**:
1. P0 alert triggered
2. On-call engineer paged immediately
3. If no ack in 5 minutes, escalate to secondary on-call
4. If no resolution in 15 minutes, escalate to engineering lead

---

## Test Harness Instructions

### Induce Network Conditions

Use `tc` (Traffic Control) on Linux to simulate network issues:

#### Induce Latency (100ms)
```bash
sudo tc qdisc add dev eth0 root netem delay 100ms
```

#### Induce Jitter (50ms ±20ms variance)
```bash
sudo tc qdisc add dev eth0 root netem delay 50ms 20ms
```

#### Induce Packet Loss (5%)
```bash
sudo tc qdisc add dev eth0 root netem loss 5%
```

#### Combine Multiple Conditions (realistic)
```bash
sudo tc qdisc add dev eth0 root netem delay 80ms 10ms loss 2% corrupt 0.1%
```

#### Reset Network Conditions
```bash
sudo tc qdisc del dev eth0 root
```

### Verify Desync Detection

**Test Scenario 1: Position Drift**

1. Start multiplayer game (1 host, 1 client)
2. Pause client simulation (breakpoint or manual)
3. Allow server to advance 5 seconds (100 ticks)
4. Resume client simulation
5. **Expected**: Client detects desync within 0.5s (hash mismatch)
6. **Expected**: Client initiates hard recovery (snapshot request)
7. **Expected**: Client resynchronizes within 3s

**Validation**:
```bash
grep "desync_detected" metrics/raw/desync_*.json
# Should show 1 event with drift_magnitude > 5.0
```

**Test Scenario 2: Enemy Health Mismatch**

1. Start game, spawn 10 enemies
2. Manually modify enemy health on client (debugger)
3. Continue simulation for 10 ticks
4. **Expected**: Hash mismatch detected
5. **Expected**: Server corrects client state (soft recovery)

**Validation**:
```bash
grep "desync_recovery_time" metrics/raw/desync_*.json | jq '.recovery_method'
# Should show "soft"
```

### Verify Reconciliation

**Test Scenario 3: Join-In-Progress**

1. Start game with 1 player, reach wave 3
2. Join 2nd player mid-wave
3. Verify 2nd player receives WORLD_STATE snapshot
4. **Expected**: 2nd player sees all active enemies
5. **Expected**: No desyncs for 2nd player after join

**Validation**:
```bash
# Check that player 2 received snapshot
grep "WORLD_STATE" logs/server.log | grep "player_id: 2"

# Check no desyncs for player 2 in first 30s after join
grep "desync_detected" metrics/raw/desync_*.json | \
  jq 'select(.player_id == 2 and .timestamp_ms < join_time + 30000)'
# Should return 0 results
```

### Automated Test Suite

**Location**: `tests/integration/test_network_resilience.py`

```python
import pytest
from test_harness import NetworkSimulator, GameSession

@pytest.mark.integration
def test_desync_recovery_under_high_latency():
    """Verify desync recovery works with 100ms latency."""
    sim = NetworkSimulator()
    sim.set_latency(100)  # 100ms
    
    session = GameSession.start_multiplayer(players=2)
    session.advance_to_wave(3)
    
    # Introduce desync
    session.clients[0].corrupt_state(enemy_id=123, health=-50)
    
    # Wait for detection
    session.wait_for_event("desync_detected", timeout=1.0)
    
    # Verify recovery
    assert session.is_synced(timeout=3.0)
    assert session.clients[0].get_enemy_health(123) == session.server.get_enemy_health(123)

@pytest.mark.integration
def test_join_in_progress_with_packet_loss():
    """Verify join-in-progress works with 5% packet loss."""
    sim = NetworkSimulator()
    sim.set_packet_loss(0.05)  # 5%
    
    session = GameSession.start_multiplayer(players=1)
    session.advance_to_wave(5)
    
    # Join 2nd player mid-wave
    session.add_player(player_id=2)
    
    # Verify state sync
    assert session.clients[1].enemy_count() == session.server.enemy_count()
    assert session.clients[1].battleship_health() == session.server.battleship_health()
```

**Run Tests**:
```bash
pytest tests/integration/test_network_resilience.py -v
```

---

## Telemetry Collection Workflow

### Manual Collection (Development)

1. **Instrument Code**:
   ```csharp
   // Unity C# Example
   TelemetryLogger.LogMarker("ar_latency_total", latency_ms, frame_number);
   ```

2. **Run Game Session**:
   ```bash
   # Start game with telemetry enabled
   unity-player --enable-telemetry --output-dir=metrics/raw/
   ```

3. **Collect Metrics**:
   ```bash
   # Metrics written to metrics/raw/ar_latency_total_{timestamp}.json
   ls -lh metrics/raw/
   ```

4. **Generate Report**:
   ```bash
   python3 tools/collect_runtime_metrics.py
   # Updates PERFORMANCE_STATUS.md and reports/dashboard.html
   ```

### Automated Collection (CI Pipeline)

**GitHub Actions Workflow** (`.github/workflows/telemetry_collection.yml`):

```yaml
name: Telemetry Collection

on:
  schedule:
    - cron: '0 */6 * * *'  # Every 6 hours
  workflow_dispatch:  # Manual trigger

jobs:
  collect-telemetry:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Run Automated Test Suite
        run: |
          pytest tests/integration/test_network_resilience.py --junitxml=test-results.xml
      
      - name: Collect Telemetry
        run: |
          python3 tools/collect_runtime_metrics.py
      
      - name: Upload Metrics
        uses: actions/upload-artifact@v3
        with:
          name: telemetry-metrics
          path: metrics/raw/*.json
      
      - name: Generate Dashboard
        run: |
          python3 scripts/generate_dashboard.py --output reports/dashboard.html
      
      - name: Check Thresholds
        run: |
          python3 scripts/check_telemetry_thresholds.py || exit 1
```

---

## References

- **Design Specification**: [design.md](./design.md)
- **Telemetry Integration Guide**: [docs/TELEMETRY_INTEGRATION.md](../../TELEMETRY_INTEGRATION.md)
- **Performance Status**: [PERFORMANCE_STATUS.md](../../../PERFORMANCE_STATUS.md)
- **Telemetry Issue**: [#199](https://github.com/BladeWireless/blade-sdk/issues/199)
- **Implementation Issue**: [#185](https://github.com/BladeWireless/blade-sdk/issues/185)

---

**Document Version**: 1.0  
**Last Updated**: 2025-01-15  
**Status**: Ready for Instrumentation
