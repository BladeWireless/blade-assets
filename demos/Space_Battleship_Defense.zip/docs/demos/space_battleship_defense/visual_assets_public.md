# Space Battleship Defense - Public Visual Asset Gallery
# スペース・バトルシップ・ディフェンス - 公開ビジュアルアセットギャラリー

**Status**: Public Documentation  
**Related Documents**: [Design Specification](./design.md) | [Asset Specification](./assets.md) | [Gameplay Storyboard](./storyboard_public.md) | [README](./README.md)  
**Implementation**: [Issue #185](https://github.com/BladeWireless/blade-sdk/issues/185) - Space Battleship Defense Implementation  
**Visual Gallery**: [Issue #270](https://github.com/BladeWireless/blade-sdk/issues/270) - Visual Asset Gallery and Storyboard  
**Asset Pipeline**: [Issue #198](https://github.com/BladeWireless/blade-sdk/issues/198) | [Asset Pipeline Overview](../../asset_pipeline_overview.md)  
**License Mapping**: `licenses/asset_licenses.yaml`

---

## Overview | 概要

This document provides a developer-facing visual reference gallery for all assets used in the Space Battleship Defense AR demo. All content is sanitized for public consumption and does not include confidential technical details, proprietary specifications, or internal development notes.

このドキュメントは、Space Battleship Defense ARデモで使用されるすべてのアセットの開発者向けビジュアルリファレンスギャラリーを提供します。すべてのコンテンツは公開用にサニタイズされており、機密技術情報、独自仕様、または内部開発ノートは含まれていません。

**Purpose**: Enable external developers to understand asset requirements, poly budgets, texture specifications, and Unity integration workflows.

**目的**: 外部開発者がアセット要件、ポリゴン予算、テクスチャ仕様、Unity統合ワークフローを理解できるようにすること。

---

## Asset Categories | アセットカテゴリー

- [1. Hikari Battleship (Hero Asset)](#1-hikari-battleship-hero-asset--光戦艦ヒカリ主要アセット)
- [2. UFO Enemies](#2-ufo-enemies--ufo敵)
- [3. Projectiles & Weapons](#3-projectiles--weapons--発射物と武器)
- [4. Visual Effects (VFX)](#4-visual-effects-vfx--視覚効果)
- [5. HUD & UI Elements](#5-hud--ui-elements--hudとui要素)
- [6. Audio Cues](#6-audio-cues--オーディオキュー)
- [7. Unity Import Guidelines](#7-unity-import-guidelines--unity-インポートガイドライン)

---

## 1. Hikari Battleship (Hero Asset) | 光戦艦「ヒカリ」（主要アセット）

The Hikari battleship is the player's primary defensive asset. It features multiple LOD levels for performance optimization.

ヒカリ戦艦はプレイヤーの主要防衛アセットです。パフォーマンス最適化のために複数のLODレベルを備えています。

### Primary Model | 主要モデル

<img src="../../assets/space_battleship_defense_public/hikari_battleship_thumb.svg" alt="Hikari Battleship" width="400"/>

| Field | EN Value | JA Value (日本語) |
|-------|----------|-------------------|
| **ID** | `hikari_battleship_main` | `hikari_battleship_main` |
| **Path** | `Assets/SpaceBattleshipDefense/Models/Hikari/Hikari_LOD0.fbx` | `Assets/SpaceBattleshipDefense/Models/Hikari/Hikari_LOD0.fbx` |
| **Poly Count (LOD0)** | 8,000 triangles | 8,000 ポリゴン |
| **Textures** | Albedo (2048x2048, sRGB, ETC2)<br/>Normal (2048x2048, Linear, ETC2)<br/>MetallicSmoothness (2048x2048, Linear, ETC2)<br/>Emissive (1024x1024, sRGB, ETC2) | アルベド (2048x2048, sRGB, ETC2)<br/>ノーマル (2048x2048, Linear, ETC2)<br/>メタリックスムースネス (2048x2048, Linear, ETC2)<br/>エミッシブ (1024x1024, sRGB, ETC2) |
| **Materials** | 3 (hull, windows, engines) | 3 (船体、窓、エンジン) |
| **Animations** | None (static, VFX driven) | なし（静的、VFX駆動） |
| **LOD Levels** | LOD0, LOD1, LOD2 | LOD0、LOD1、LOD2 |
| **Memory Budget** | ~8 MB (LOD0, compressed) | 約8 MB (LOD0、圧縮済み) |

**Notes (EN)**: The Hikari battleship represents the player's last line of defense. The design emphasizes sleek, futuristic aesthetics with distinctive blue-white color scheme and glowing engine effects. All textures use Unity Standard Shader with metallic workflow.

**ノート (JA)**: ヒカリ戦艦はプレイヤーの最後の防衛線を表します。デザインは、滑らかで未来的な美学を強調し、特徴的な青白い色スキームと光るエンジンエフェクトを備えています。すべてのテクスチャは、メタリックワークフローを備えたUnity Standard Shaderを使用しています。

**Download**: Assets included in SDK package under `Assets/SpaceBattleshipDefense/Models/Hikari/`

### LOD Configuration | LOD 構成

| LOD Level | Distance Range | Poly Count | Texture Resolution | Memory |
|-----------|----------------|------------|-------------------|---------|
| LOD0 | 0-20m | 8,000 tris | 2048x2048 | 8 MB |
| LOD1 | 20-50m | 4,000 tris | 1024x1024 | 2 MB |
| LOD2 | 50m+ | 2,000 tris | 512x512 | 512 KB |

---

## 2. UFO Enemies | UFO敵

Four enemy types with escalating difficulty and visual complexity.

難易度と視覚的な複雑さがエスカレートする4つの敵タイプ。

### Small UFO | 小型UFO

<img src="../../assets/space_battleship_defense_public/ufo_small_thumb.svg" alt="Small UFO" width="400"/>

| Field | EN Value | JA Value |
|-------|----------|----------|
| **ID** | `ufo_small` | `ufo_small` |
| **Path** | `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Small_LOD0.fbx` | `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Small_LOD0.fbx` |
| **Poly Count (LOD0)** | 1,000 triangles | 1,000 ポリゴン |
| **Textures** | Albedo (512x512), Normal (512x512), Emissive (256x256) | アルベド (512x512)、ノーマル (512x512)、エミッシブ (256x256) |
| **Materials** | 1 | 1 |
| **LOD Levels** | 3 (LOD0, LOD1, LOD2/Billboard) | 3 (LOD0、LOD1、LOD2/ビルボード) |

**Notes (EN)**: Fast-moving scout enemies. Green color scheme with glowing lights. Suitable for instanced rendering (up to 50 simultaneous).

**ノート (JA)**: 高速移動偵察敵。光るライト付きの緑の色スキーム。インスタンスレンダリングに適しています（最大50個同時）。

---

### Medium UFO | 中型UFO

<img src="../../assets/space_battleship_defense_public/ufo_medium_thumb.svg" alt="Medium UFO" width="400"/>

| Field | EN Value | JA Value |
|-------|----------|----------|
| **ID** | `ufo_medium` | `ufo_medium` |
| **Path** | `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Medium_LOD0.fbx` | `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Medium_LOD0.fbx` |
| **Poly Count (LOD0)** | 1,500 triangles | 1,500 ポリゴン |
| **Textures** | Albedo (512x512), recolored variant of Small UFO | アルベド (512x512)、小型UFOの色変更バリアント |
| **Materials** | 1 | 1 |
| **LOD Levels** | 3 | 3 |

**Notes (EN)**: Balanced enemy type with moderate speed and health. Red color scheme distinguishes from scout type.

**ノート (JA)**: 中程度の速度と体力を持つバランスの取れた敵タイプ。赤い色スキームが偵察タイプと区別されます。

---

### Heavy UFO | 重型UFO

<img src="../../assets/space_battleship_defense_public/ufo_heavy_thumb.svg" alt="Heavy UFO" width="400"/>

| Field | EN Value | JA Value |
|-------|----------|----------|
| **ID** | `ufo_heavy` | `ufo_heavy` |
| **Path** | `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Heavy_LOD0.fbx` | `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Heavy_LOD0.fbx` |
| **Poly Count (LOD0)** | 2,500 triangles | 2,500 ポリゴン |
| **Textures** | Albedo (1024x1024), Normal (1024x1024), Emissive (512x512) | アルベド (1024x1024)、ノーマル (1024x1024)、エミッシブ (512x512) |
| **Materials** | 2 (body, armor plates) | 2 (本体、装甲板) |
| **LOD Levels** | 3 | 3 |

**Notes (EN)**: Slow-moving tank enemies with high health. Purple color scheme with armored appearance.

**ノート (JA)**: 高体力の低速移動タンク敵。装甲の外観を持つ紫色のスキーム。

---

### Boss UFO | ボスUFO

<img src="../../assets/space_battleship_defense_public/ufo_boss_thumb.svg" alt="Boss UFO" width="400"/>

| Field | EN Value | JA Value |
|-------|----------|----------|
| **ID** | `ufo_boss` | `ufo_boss` |
| **Path** | `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Boss_LOD0.fbx` | `Assets/SpaceBattleshipDefense/Models/Enemies/UFO_Boss_LOD0.fbx` |
| **Poly Count (LOD0)** | 4,000 triangles | 4,000 ポリゴン |
| **Textures** | Albedo (1024x1024), Normal (1024x1024), Emissive (512x512), Detail (512x512) | アルベド (1024x1024)、ノーマル (1024x1024)、エミッシブ (512x512)、ディテール (512x512) |
| **Materials** | 2 (body, details) | 2 (本体、ディテール) |
| **Animations** | Rotate, Pulse (shader-based) | 回転、パルス（シェーダーベース） |
| **LOD Levels** | 3 | 3 |

**Notes (EN)**: Appears in finale sequence. Orange/gold color scheme with distinctive antenna. Features animated shader effects for visual impact.

**ノート (JA)**: フィナーレシーケンスに登場。特徴的なアンテナ付きのオレンジ/ゴールド色スキーム。視覚的インパクトのためのアニメーションシェーダーエフェクトを備えています。

---

## 3. Projectiles & Weapons | 発射物と武器

### Player Laser Projectile | プレイヤーレーザー発射物

<img src="../../assets/space_battleship_defense_public/projectile_laser_thumb.svg" alt="Player Laser" width="400"/>

| Field | EN Value | JA Value |
|-------|----------|----------|
| **ID** | `projectile_player_laser` | `projectile_player_laser` |
| **Path** | `Assets/SpaceBattleshipDefense/Models/Projectiles/Laser_Bolt.fbx` | `Assets/SpaceBattleshipDefense/Models/Projectiles/Laser_Bolt.fbx` |
| **Poly Count** | 20 triangles (elongated capsule) | 20 ポリゴン（細長いカプセル） |
| **Textures** | Emissive (128x128, sRGB, uncompressed) | エミッシブ (128x128, sRGB, 非圧縮) |
| **Materials** | 1 (additive shader) | 1 (加算シェーダー) |
| **Instanced** | Yes (up to 200 simultaneous) | はい（最大200個同時） |

**Notes (EN)**: Cyan-blue laser bolts fired from Hikari battleship. Uses additive blending for bright, energetic appearance. Optimized for GPU instancing.

**ノート (JA)**: ヒカリ戦艦から発射されるシアンブルーレーザー弾。明るく、エネルギッシュな外観のために加算ブレンディングを使用。GPUインスタンシング用に最適化されています。

---

### Enemy Plasma Projectile | 敵プラズマ発射物

<img src="../../assets/space_battleship_defense_public/projectile_plasma_thumb.svg" alt="Enemy Plasma" width="400"/>

| Field | EN Value | JA Value |
|-------|----------|----------|
| **ID** | `projectile_enemy_plasma` | `projectile_enemy_plasma` |
| **Path** | `Assets/SpaceBattleshipDefense/Models/Projectiles/Plasma_Bolt.fbx` | `Assets/SpaceBattleshipDefense/Models/Projectiles/Plasma_Bolt.fbx` |
| **Poly Count** | 20 triangles | 20 ポリゴン |
| **Textures** | Emissive (128x128, sRGB, uncompressed) | エミッシブ (128x128, sRGB, 非圧縮) |
| **Materials** | 1 (additive shader, color varies by enemy) | 1 (加算シェーダー、敵によって色が変わる) |

**Notes (EN)**: Orange-red plasma bolts fired by UFO enemies. Material supports color tinting to match enemy type.

**ノート (JA)**: UFO敵によって発射されるオレンジレッドプラズマ弾。敵タイプに合わせた色の濃淡をサポートするマテリアル。

---

## 4. Visual Effects (VFX) | 視覚効果

<img src="../../assets/space_battleship_defense_public/vfx_explosion_thumb.svg" alt="Explosion VFX" width="400"/>

### Explosion Effects | 爆発エフェクト

| Effect Type | ID | Particle Count | Duration | Memory |
|-------------|-----|----------------|----------|---------|
| **Small Explosion** (Enemy Death) | `vfx_explosion_small` | 50-100 | 1.5s | ~500 KB |
| **Large Explosion** (Boss Death) | `vfx_explosion_large` | 200-300 | 3.0s | ~1 MB |
| **Hit Spark** | `vfx_hit_enemy` | 10-20 | 0.5s | ~100 KB |

**Textures**: Flipbook sprite sheets (4x4 atlases), ETC2 compressed

**テクスチャ**: フリップブックスプライトシート（4x4アトラス）、ETC2圧縮済み

**Notes (EN)**: Particle systems use GPU particles for efficient rendering. All effects use additive blending with bloom post-processing for cinematic impact.

**ノート (JA)**: パーティクルシステムは効率的なレンダリングのためにGPUパーティクルを使用します。すべてのエフェクトは、映画的なインパクトのためにブルームポストプロセッシングを備えた加算ブレンディングを使用します。

### Weapon Fire Effects | 武器発射エフェクト

| Effect Type | ID | Duration | Notes |
|-------------|-----|----------|-------|
| **Muzzle Flash** | `vfx_muzzle_flash` | 0.2s | Instantaneous flash at weapon fire point |
| **Superweapon Charge** | `vfx_superweapon_charge` | 10s | Continuous particle emission during finale |
| **Superweapon Beam** | `vfx_superweapon_beam` | 2s | Mesh-based beam with scrolling texture |

**Path**: `Assets/SpaceBattleshipDefense/VFX/`

---

## 5. HUD & UI Elements | HUDとUI要素

<img src="../../assets/space_battleship_defense_public/ui_hud_thumb.svg" alt="HUD Elements" width="400"/>

### HUD Components | HUDコンポーネント

| Component | ID | Size/Format | Dynamic Updates |
|-----------|-----|-------------|-----------------|
| **Health Bar** | `ui_health_bar` | 512x64 PNG (RGBA) | Per-frame fill updates |
| **Wave Counter** | `ui_wave_counter` | 256x256 PNG | Between-wave updates |
| **Reticle** | `ui_reticle` | 128x128 PNG (RGBA) | Target lock variants |
| **Score Display** | `ui_score_display` | Vector font (24pt) | Per-kill updates |

**Fonts**:
- `RobotoMono_Regular.ttf` (Apache 2.0 License) - Score, timer, wave counter
- `Orbitron_Bold.ttf` (SIL Open Font License) - Title screen, headers

**Notes (EN)**: UI uses Unity's Canvas system with world-space overlay mode for AR integration. All UI elements scale based on distance from viewer.

**ノート (JA)**: UIは、AR統合のためにワールドスペースオーバーレイモードを備えたUnityのCanvasシステムを使用します。すべてのUI要素は、視聴者からの距離に基づいてスケールします。

### Menu Screens | メニュー画面

| Screen | ID | Background Resolution | Notes |
|--------|-----|----------------------|-------|
| **Title Screen** | `ui_title_screen` | 1920x1080 ETC2 | Main menu entry point |
| **Victory Screen** | `ui_victory_screen` | 1920x1080 ETC2 | Post-game celebration |
| **Defeat Screen** | `ui_defeat_screen` | 1920x1080 ETC2 | Game over state |

**Path**: `Assets/SpaceBattleshipDefense/UI/`

---

## 6. Audio Cues | オーディオキュー

### Sound Effects (SFX) | 効果音

| Category | ID | Format | Duration | File Size |
|----------|-----|--------|----------|-----------|
| **Player Laser Fire** | `sfx_laser_fire` | Ogg Vorbis, 48kHz, Mono | 0.3s | ~15 KB |
| **Enemy Plasma Fire** | `sfx_plasma_fire` | Ogg Vorbis, 48kHz, Mono | 0.4s | ~18 KB |
| **Small Explosion** | `sfx_explosion_small` | Ogg Vorbis, 48kHz, Stereo | 1.2s | ~40 KB |
| **Large Explosion** | `sfx_explosion_large` | Ogg Vorbis, 48kHz, Stereo | 2.5s | ~80 KB |
| **Hit Impact** | `sfx_hit_enemy` | Ogg Vorbis, 48kHz, Mono | 0.2s | ~10 KB |
| **Button Click** | `sfx_button_click` | Ogg Vorbis, 48kHz, Mono | 0.1s | ~5 KB |
| **Wave Complete** | `sfx_wave_complete` | Ogg Vorbis, 48kHz, Stereo | 2.0s | ~60 KB |

**Total SFX Size**: ~1 MB (compressed)

**Path**: `Assets/SpaceBattleshipDefense/Audio/SFX/`

**Notes (EN)**: All SFX use Ogg Vorbis compression for efficient memory usage. Spatial audio support enabled for 3D positioning.

**ノート (JA)**: すべてのSFXは、効率的なメモリ使用のためにOgg Vorbis圧縮を使用します。3D配置のための空間オーディオサポートが有効になっています。

### Music Tracks | 音楽トラック

| Track | ID | Format | Duration | File Size | License |
|-------|-----|--------|----------|-----------|---------|
| **Combat Loop** | `music_combat` | Ogg Vorbis, 48kHz, Stereo | 120s (loop) | ~3 MB | Royalty-free |
| **Finale Theme** | `music_finale` | Ogg Vorbis, 48kHz, Stereo | 25s | ~600 KB | Royalty-free |
| **Victory Fanfare** | `music_victory` | Ogg Vorbis, 48kHz, Stereo | 10s | ~250 KB | Royalty-free |
| **Defeat Stinger** | `music_defeat` | Ogg Vorbis, 48kHz, Stereo | 5s | ~120 KB | Royalty-free |

**Total Music Size**: ~4 MB (compressed)

**Path**: `Assets/SpaceBattleshipDefense/Audio/Music/`

---

## 7. Unity Import Guidelines | Unity インポートガイドライン

### Folder Structure | フォルダー構造

Recommended Unity project structure for Space Battleship Defense assets:

Space Battleship Defenseアセット用の推奨Unityプロジェクトフォルダー構造：

```
Assets/
└── SpaceBattleshipDefense/
    ├── Models/
    │   ├── Hikari/
    │   │   ├── Hikari_LOD0.fbx
    │   │   ├── Hikari_LOD1.fbx
    │   │   ├── Hikari_LOD2.fbx
    │   │   └── Materials/
    │   │       ├── Hikari_Albedo.png
    │   │       ├── Hikari_Normal.png
    │   │       ├── Hikari_MetallicSmoothness.png
    │   │       └── Hikari_Emissive.png
    │   ├── Enemies/
    │   │   ├── UFO_Small_LOD0.fbx
    │   │   ├── UFO_Medium_LOD0.fbx
    │   │   ├── UFO_Heavy_LOD0.fbx
    │   │   ├── UFO_Boss_LOD0.fbx
    │   │   └── Materials/
    │   └── Projectiles/
    │       ├── Laser_Bolt.fbx
    │       └── Plasma_Bolt.fbx
    ├── VFX/
    │   ├── Explosion_Small.prefab
    │   ├── Explosion_Large.prefab
    │   ├── Hit_Spark.prefab
    │   ├── Muzzle_Flash.prefab
    │   └── Textures/
    │       ├── Explosion_Atlas.png
    │       └── Beam_Gradient.png
    ├── UI/
    │   ├── Textures/
    │   │   ├── HealthBar.png
    │   │   ├── WaveCounter.png
    │   │   ├── Reticle.png
    │   │   └── Button_Atlas.png
    │   ├── Fonts/
    │   │   ├── RobotoMono_Regular.ttf
    │   │   └── Orbitron_Bold.ttf
    │   └── Prefabs/
    │       ├── TitleScreen.prefab
    │       ├── VictoryScreen.prefab
    │       └── DefeatScreen.prefab
    └── Audio/
        ├── SFX/
        │   ├── Laser_Fire.ogg
        │   ├── Plasma_Fire.ogg
        │   ├── Explosion_Small.ogg
        │   └── Explosion_Large.ogg
        └── Music/
            ├── Combat_Loop.ogg
            ├── Finale_Theme.ogg
            ├── Victory_Fanfare.ogg
            └── Defeat_Stinger.ogg
```

### Naming Conventions | 命名規則

**Models | モデル**:
- Use `PascalCase` for model files: `Hikari_LOD0.fbx`
- Include LOD level in filename: `_LOD0`, `_LOD1`, `_LOD2`
- Use descriptive names: `UFO_Small`, `UFO_Boss`

**Textures | テクスチャ**:
- Use `PascalCase` with texture type suffix: `Hikari_Albedo.png`, `Hikari_Normal.png`
- Standard suffixes: `_Albedo`, `_Normal`, `_MetallicSmoothness`, `_Emissive`
- Match model name prefix for easy identification

**Audio | オーディオ**:
- Use `snake_case` for audio files: `laser_fire.ogg`, `explosion_small.ogg`
- Include category prefix: `sfx_`, `music_`

### LOD Import Settings | LOD インポート設定

**Unity Import Settings for Models**:

1. **FBX Import Settings**:
   - Scale Factor: 1
   - Convert Units: Enabled
   - Import BlendShapes: Disabled (not used)
   - Import Visibility: Enabled
   - Import Cameras: Disabled
   - Import Lights: Disabled
   - Preserve Hierarchy: Enabled

2. **LOD Group Configuration**:
   ```csharp
   // Example LOD Group setup
   LODGroup lodGroup = gameObject.AddComponent<LODGroup>();
   LOD[] lods = new LOD[3];
   
   // LOD0: 0-20m (100% to 50% screen height)
   lods[0] = new LOD(0.5f, renderers_LOD0);
   
   // LOD1: 20-50m (50% to 20% screen height)
   lods[1] = new LOD(0.2f, renderers_LOD1);
   
   // LOD2: 50m+ (20% to 5% screen height)
   lods[2] = new LOD(0.05f, renderers_LOD2);
   
   lodGroup.SetLODs(lods);
   lodGroup.RecalculateBounds();
   ```

### Texture Import Settings | テクスチャインポート設定

**Recommended Unity Texture Import Settings**:

| Texture Type | sRGB | Compression | Max Size | Mip Maps |
|--------------|------|-------------|----------|----------|
| **Albedo** | Yes | ETC2 (Android/AR) | 2048x2048 | Yes |
| **Normal** | No | ETC2 | 2048x2048 | Yes |
| **Metallic/Smoothness** | No | ETC2 | 2048x2048 | Yes |
| **Emissive** | Yes | ETC2 | 1024x1024 | Yes |
| **UI Textures** | Yes | None (RGBA32) | 512x512 | No |

**Mip Map Bias**: Set to -0.5 for sharper textures in AR scenarios

**Anisotropic Filtering**: Set to 2x or 4x for better quality at oblique viewing angles

### Audio Import Settings | オーディオインポート設定

**Unity Audio Import Settings**:

| Audio Type | Load Type | Compression Format | Quality | Preload |
|------------|-----------|-------------------|---------|---------|
| **SFX** | Decompress On Load | Vorbis | 70% | Yes |
| **Music** | Streaming | Vorbis | 70% | No |
| **UI Sounds** | Decompress On Load | Vorbis | 50% | Yes |

**3D Sound Settings**:
- Spatial Blend: 1.0 (full 3D) for gameplay SFX
- Spatial Blend: 0.0 (2D) for UI sounds
- Doppler Level: 0.5
- Min Distance: 1m
- Max Distance: 50m

### Asset Manifest Integration | アセットマニフェスト統合

All assets are tracked in the automated manifest system. See [Asset Specification](./assets.md) for manifest generation details.

すべてのアセットは、自動化されたマニフェストシステムで追跡されます。マニフェスト生成の詳細については、[Asset Specification](./assets.md)を参照してください。

**Generate Manifest**:
```bash
python3 scripts/gen_space_battleship_asset_manifest.py
```

**Output**: `manifests/space_battleship_defense_manifest.yaml`

**Validation**:
```bash
python3 scripts/validate_asset_licenses.py --manifest manifests/space_battleship_defense_manifest.yaml
```

---

## Asset Budget Summary | アセット予算サマリー

| Category | Count | Poly Budget | Texture Budget | Memory Budget |
|----------|-------|-------------|----------------|---------------|
| **Battleship** | 1 | 8,000 tris | 8 MB | 10 MB |
| **Enemies** | 4 types | 9,000 tris | 4 MB | 6 MB |
| **Projectiles** | 2 | 40 tris | 256 KB | 500 KB |
| **VFX** | 10+ effects | 1,000 tris | 4 MB | 6 MB |
| **UI** | 15+ elements | N/A | 8 MB | 10 MB |
| **Audio (SFX)** | 15+ files | N/A | N/A | 1 MB |
| **Audio (Music)** | 4 tracks | N/A | N/A | 4 MB |
| **Total** | **50+ assets** | **~18,000 tris** | **~24 MB** | **~38 MB** |

**Note**: All sizes reflect compressed/runtime memory usage. Uncompressed source assets are 4-6x larger.

**ノート**: すべてのサイズは圧縮/ランタイムメモリ使用量を反映しています。非圧縮ソースアセットは4〜6倍大きくなります。

---

## Cross-References | クロスリファレンス

### Related Documentation | 関連ドキュメント

- **[Design Specification](./design.md)** - Complete technical design including gameplay loops, networking, and performance budgets
- **[Asset Specification](./assets.md)** - Detailed technical specifications, LOD tables, and manifest integration
- **[Gameplay Storyboard](./storyboard_public.md)** - Visual storyboard showing 60-second defense loop and SDK features
- **[README](./README.md)** - Documentation index and quick navigation
- **[Asset Pipeline Overview](../../asset_pipeline_overview.md)** - General asset pipeline documentation

### Asset Licensing | アセットライセンス

All assets are documented in `licenses/asset_licenses.yaml` with appropriate attribution:

- **Models**: BladeWireless Internal / CC0 (Modified)
- **Textures**: BladeWireless Internal (procedurally generated)
- **Audio SFX**: Freesound.org CC0/CC-BY (see `AUDIO_CREDITS.txt`)
- **Audio Music**: Licensed from royalty-free providers
- **Fonts**: Apache 2.0 (Roboto Mono) / SIL OFL 1.1 (Orbitron)

For detailed license information, refer to `licenses/asset_licenses.yaml` and individual asset credits files.

---

## Download & SDK Package | ダウンロードとSDKパッケージ

**Availability**: All assets listed in this gallery are included in the Blade SDK package.

**利用可能性**: このギャラリーにリストされているすべてのアセットは、Blade SDKパッケージに含まれています。

**Package Location**: 
- Unity Package: `samples/unity/SpaceBattleshipDefense/`
- Unreal Package: `samples/unreal/SpaceBattleshipDefense/`

**Installation**: See [SDK Quickstart Guide](../../sdk_quickstart.md) for installation instructions.

---

## Questions & Feedback | 質問とフィードバック

For questions about asset integration or technical specifications:

- Open an issue referencing `#185` (Space Battleship Defense Implementation)
- Review the [Asset Specification](./assets.md) for detailed technical information
- Contact the SDK team via GitHub Discussions

アセット統合または技術仕様に関する質問については：

- `#185`（Space Battleship Defense実装）を参照してissueを開く
- 詳細な技術情報については、[Asset Specification](./assets.md)を確認してください
- GitHub Discussionsを介してSDKチームに連絡してください

---

**Document Version**: 1.0  
**Last Updated**: 2025-10-13  
**Status**: Public Documentation
