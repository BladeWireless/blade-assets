# Space Battleship Defense - Design Specification

**Status**: Design Phase - Authoritative Spec for Implementation  
**Implementation Issue**: [#185](https://github.com/BladeWireless/blade-sdk/issues/185)  
**Related PRs**: [#207](https://github.com/BladeWireless/blade-sdk/pull/207), [#208](https://github.com/BladeWireless/blade-sdk/pull/208)  
**Dependencies**: Asset Pipeline (#198), Telemetry (#199), Localization (#200)

---

## Overview

Space Battleship Defense is a cooperative AR tower defense game where players defend the Hikari battleship against waves of UFO enemies. The game features a 60-second defense loop, network multiplayer support, and a climactic superweapon finale.

### Key Features
- **60-second intense defense loops** with escalating enemy waves
- **Cooperative multiplayer** (1-4 players) with host/client architecture
- **Authoritative server model** with client-side prediction
- **Fixed-timestep simulation** for deterministic gameplay
- **Epic finale sequence** with superweapon activation
- **AR-first design** optimized for MiRZA glasses

---

## 60-Second Defense Loop

### Loop Overview

Each defense wave follows a tight 60-second cycle designed for intense, focused gameplay:

```
[0s]    Wave Start → Enemy Spawn Begin
[10s]   First Wave Peak (30% enemies spawned)
[25s]   Second Wave Peak (65% enemies spawned)
[40s]   Final Wave Peak (100% enemies spawned)
[50s]   Last Enemy Spawned
[60s]   Wave Complete (or timeout)
        ↓
        Victory Check → Next Wave or Finale
```

### State Diagram

```
                    ┌─────────────────┐
                    │   LOBBY_WAIT    │
                    │  Players Join   │
                    └────────┬────────┘
                             │ Host starts
                             ↓
                    ┌─────────────────┐
                    │  WAVE_PREPARE   │
                    │   5s Countdown  │
                    └────────┬────────┘
                             │
                             ↓
         ┌──────────► ┌─────────────────┐
         │            │   WAVE_ACTIVE   │ ◄──┐
         │            │ 60s Defense Loop│    │
         │            └────────┬────────┘    │
         │                     │             │
         │                     ↓             │
         │            ┌─────────────────┐    │
         │            │  WAVE_COMPLETE  │    │
         │            │ +3s Celebration │    │
         │            └────────┬────────┘    │
         │                     │             │
         │                     ├─────────────┘
         │                     │ More waves
         │                     │
         │                     ↓
         │            ┌─────────────────┐
         │            │ FINALE_TRIGGER  │
         │            │  Superweapon!   │
         │            └────────┬────────┘
         │                     │
         │                     ↓
         │            ┌─────────────────┐
         │            │ FINALE_SEQUENCE │
         │            │   20s Cutscene  │
         │            └────────┬────────┘
         │                     │
         │                     ↓
         │            ┌─────────────────┐
         │            │  VICTORY/DEFEAT │
         │            │   End Screen    │
         │            └────────┬────────┘
         │                     │
         │                     ↓ Retry
         └─────────────────────┘
```

### State Transitions

| From State       | To State        | Trigger                          | Authority |
|------------------|-----------------|----------------------------------|-----------|
| LOBBY_WAIT       | WAVE_PREPARE    | Host starts game                 | Host      |
| WAVE_PREPARE     | WAVE_ACTIVE     | 5s countdown expires             | Server    |
| WAVE_ACTIVE      | WAVE_COMPLETE   | All enemies defeated OR 60s timeout | Server |
| WAVE_ACTIVE      | DEFEAT          | Battleship health ≤ 0            | Server    |
| WAVE_COMPLETE    | WAVE_PREPARE    | Wave < MAX_WAVES                 | Server    |
| WAVE_COMPLETE    | FINALE_TRIGGER  | Wave == MAX_WAVES                | Server    |
| FINALE_TRIGGER   | FINALE_SEQUENCE | Superweapon charged (3s)         | Server    |
| FINALE_SEQUENCE  | VICTORY         | Finale completes successfully    | Server    |
| FINALE_SEQUENCE  | DEFEAT          | Battleship destroyed during finale | Server |
| VICTORY/DEFEAT   | LOBBY_WAIT      | Host selects retry               | Host      |

---

## Roles and Responsibilities

### Host Role

**Authority**: Simulation authority, lobby control, game flow decisions

**Responsibilities**:
- Lobby management (start game, kick players)
- Difficulty selection (Easy/Normal/Hard/Extreme)
- Retry/exit decisions after game end
- Primary simulation authority (tie-breaker in P2P scenarios)

**Network Duties**:
- Broadcast game state changes
- Validate join requests
- Coordinate finale sequence timing

### Client Role

**Authority**: Local input, client-side prediction

**Responsibilities**:
- Local weapon firing and targeting
- Optimistic hit detection (server-validated)
- Local VFX/SFX triggering
- Latency compensation via prediction

**Network Duties**:
- Send input commands to server
- Receive authoritative state updates
- Reconcile prediction errors
- Report desync warnings

### Server Authority Model

All critical game state is server-authoritative:
- Enemy positions and health
- Battleship health
- Wave progression and timing
- Finale triggering
- Victory/defeat conditions

Clients may **predict** but server **validates** and **corrects**.

---

## Enemy Wave Tables

### Wave Composition

Enemies spawn in structured waves with increasing difficulty:

| Wave | Duration | Small UFOs | Medium UFOs | Heavy UFOs | Boss UFOs | Total HP |
|------|----------|------------|-------------|------------|-----------|----------|
| 1    | 60s      | 10         | 0           | 0          | 0         | 100      |
| 2    | 60s      | 12         | 3           | 0          | 0         | 180      |
| 3    | 60s      | 15         | 5           | 2          | 0         | 350      |
| 4    | 60s      | 18         | 7           | 3          | 1         | 580      |
| 5    | 60s      | 20         | 10          | 5          | 1         | 850      |
| 6    | 60s      | 25         | 12          | 7          | 2         | 1200     |
| 7    | 60s      | 30         | 15          | 10         | 2         | 1700     |
| 8    | 60s      | 35         | 18          | 12         | 3         | 2300     |
| 9    | 60s      | 40         | 22          | 15         | 3         | 3100     |
| 10   | 60s      | 50         | 25          | 20         | 4         | 4500     |

**MAX_WAVES**: 10 (finale triggers after wave 10)

### Enemy Types

#### Small UFO
- **Health**: 10 HP
- **Speed**: 12 units/s
- **Damage**: 5 HP to battleship
- **Points**: 10
- **Spawn Weight**: 60%

#### Medium UFO
- **Health**: 30 HP
- **Speed**: 8 units/s
- **Damage**: 15 HP to battleship
- **Points**: 30
- **Spawn Weight**: 25%

#### Heavy UFO
- **Health**: 80 HP
- **Speed**: 5 units/s
- **Damage**: 40 HP to battleship
- **Points**: 100
- **Spawn Weight**: 12%

#### Boss UFO
- **Health**: 200 HP
- **Speed**: 3 units/s
- **Damage**: 100 HP to battleship
- **Points**: 500
- **Spawn Weight**: 3%

### Spawn Point System

Enemies spawn from **8 fixed spawn points** arranged in a sphere around the battleship:

```
         SP1 (Front)
           ↓
    SP8  ← [Hikari] → SP2
           ↑   ↑
         SP7   SP3
           ↓
         SP4 (Back)
        ↙    ↓    ↘
      SP5   SP6    (hidden)
```

**Spawn Point Coordinates** (relative to battleship at origin):
- SP1: (0, 2, 10)   - Front Top
- SP2: (8, 1, 6)    - Right Front
- SP3: (10, 0, 0)   - Right Side
- SP4: (8, -1, -6)  - Right Back
- SP5: (0, -2, -10) - Back Bottom
- SP6: (-8, -1, -6) - Left Back
- SP7: (-10, 0, 0)  - Left Side
- SP8: (-8, 1, 6)   - Left Front

**Spawn Selection Algorithm**:
1. Randomly select spawn point with uniform distribution
2. Add random offset: ±1.5 units XY, ±0.5 units Z
3. Ensure minimum 2-unit spacing between simultaneous spawns
4. If spawn point blocked (collision), retry with next point in sequence

### Spawn Timing

**Spawn Rate Formula**:
```
spawn_interval = base_interval / (1 + wave_number * 0.1)
base_interval = 60s / total_enemies_in_wave
```

**Example (Wave 5)**:
- Total enemies: 36
- Base interval: 60 / 36 = 1.67s
- Adjusted interval: 1.67 / (1 + 5 * 0.1) = 1.11s

**Spawn Cadence**:
- **0-20s**: Spawn at 100% rate (fast ramp-up)
- **20-40s**: Spawn at 80% rate (sustain pressure)
- **40-60s**: Spawn at 120% rate (final surge)

---

## Difficulty Curves and Tuning Knobs

### Difficulty Modes

| Parameter                | Easy   | Normal | Hard   | Extreme |
|--------------------------|--------|--------|--------|---------|
| Battleship HP            | 1000   | 500    | 250    | 100     |
| Enemy HP Multiplier      | 0.7x   | 1.0x   | 1.3x   | 1.8x    |
| Enemy Speed Multiplier   | 0.8x   | 1.0x   | 1.2x   | 1.5x    |
| Enemy Damage Multiplier  | 0.7x   | 1.0x   | 1.5x   | 2.0x    |
| Spawn Rate Multiplier    | 0.8x   | 1.0x   | 1.2x   | 1.5x    |
| Player Damage Multiplier | 1.5x   | 1.0x   | 0.8x   | 0.6x    |
| Wave Timeout             | 90s    | 60s    | 45s    | 30s     |

### Tuning Knobs (Config File)

**Location**: `Assets/SpaceBattleshipDefense/Config/GameBalance.json`

```json
{
  "wave_config": {
    "max_waves": 10,
    "base_spawn_interval": 1.5,
    "spawn_interval_scaling": 0.1,
    "spawn_cadence_early": 1.0,
    "spawn_cadence_mid": 0.8,
    "spawn_cadence_final": 1.2
  },
  "enemy_config": {
    "small_ufo": {
      "health": 10,
      "speed": 12,
      "damage": 5,
      "points": 10
    },
    "medium_ufo": {
      "health": 30,
      "speed": 8,
      "damage": 15,
      "points": 30
    },
    "heavy_ufo": {
      "health": 80,
      "speed": 5,
      "damage": 40,
      "points": 100
    },
    "boss_ufo": {
      "health": 200,
      "speed": 3,
      "damage": 100,
      "points": 500
    }
  },
  "battleship_config": {
    "base_health": 500,
    "repair_rate": 0,
    "shield_capacity": 0
  },
  "weapon_config": {
    "base_damage": 10,
    "fire_rate": 3.0,
    "projectile_speed": 50
  }
}
```

### Dynamic Difficulty Adjustment (Optional)

**Not implemented in v1.0** - Future consideration for accessibility:
- Track player performance (accuracy, wave completion time)
- Adjust enemy HP/speed by ±15% between waves
- Notify players of adjustment via UI

---

## Network Event Model

### Message Types

| Message Type       | Direction      | Frequency | Size   | Ordering | Idempotent |
|--------------------|----------------|-----------|--------|----------|------------|
| PLAYER_INPUT       | Client→Server  | 30 Hz     | 24B    | Ordered  | No         |
| WORLD_STATE        | Server→Client  | 20 Hz     | 512B   | Latest   | Yes        |
| ENEMY_SPAWN        | Server→Client  | Event     | 48B    | Ordered  | No         |
| ENEMY_DEATH        | Server→Client  | Event     | 16B    | Ordered  | Yes        |
| DAMAGE_EVENT       | Server→Client  | Event     | 20B    | Ordered  | No         |
| WAVE_TRANSITION    | Server→Client  | Event     | 12B    | Ordered  | No         |
| FINALE_START       | Server→Client  | Event     | 8B     | Ordered  | No         |
| GAME_END           | Server→Client  | Event     | 16B    | Ordered  | No         |
| PLAYER_JOIN        | Client→Server  | Event     | 64B    | Ordered  | No         |
| PLAYER_LEAVE       | Client→Server  | Event     | 8B     | Ordered  | No         |
| HEARTBEAT          | Bidirectional  | 1 Hz      | 4B     | None     | Yes        |

### Message Schemas

#### PLAYER_INPUT (24 bytes)
```c
struct PlayerInput {
    uint32_t player_id;         // 4B
    uint32_t sequence_number;   // 4B (monotonic)
    uint16_t timestamp_ms;      // 2B (wrapping)
    uint8_t  button_mask;       // 1B (fire, alt_fire, etc.)
    float    aim_direction[3];  // 12B (normalized vector)
    uint8_t  padding;           // 1B
};
```

#### WORLD_STATE (512 bytes - variable)
```c
struct WorldState {
    uint32_t frame_number;         // 4B
    uint16_t timestamp_ms;         // 2B
    uint8_t  game_state;           // 1B (enum)
    uint8_t  current_wave;         // 1B
    uint16_t battleship_health;    // 2B
    uint16_t enemy_count;          // 2B
    // Array of enemy states (up to 50 enemies)
    struct {
        uint32_t enemy_id;         // 4B
        float    position[3];      // 12B
        uint8_t  health_percent;   // 1B
        uint8_t  enemy_type;       // 1B
        uint16_t flags;            // 2B
    } enemies[50];                 // 50 * 20B = 1000B max
    uint16_t compressed_size;      // 2B (actual size after compression)
};
```

#### ENEMY_SPAWN (48 bytes)
```c
struct EnemySpawn {
    uint32_t enemy_id;          // 4B (unique per game)
    uint32_t spawn_frame;       // 4B
    uint8_t  enemy_type;        // 1B
    uint8_t  spawn_point_id;    // 1B
    uint16_t padding;           // 2B
    float    position[3];       // 12B
    float    velocity[3];       // 12B
    uint32_t health;            // 4B
    uint32_t spawn_seed;        // 4B (for deterministic behavior)
};
```

#### ENEMY_DEATH (16 bytes)
```c
struct EnemyDeath {
    uint32_t enemy_id;          // 4B
    uint32_t killer_player_id;  // 4B (0 = timeout)
    uint32_t death_frame;       // 4B
    uint16_t points_awarded;    // 2B
    uint16_t padding;           // 2B
};
```

### Ordering Guarantees

**Ordered Channels** (TCP or reliable UDP):
- PLAYER_INPUT: Must arrive in sequence per player
- ENEMY_SPAWN: Must be processed in spawn order
- WAVE_TRANSITION: Must arrive before next wave enemies

**Unordered Channels** (UDP):
- WORLD_STATE: Latest state always wins
- HEARTBEAT: Any arrival is sufficient

**Hybrid Approach**:
- Use **TCP for events** (guaranteed delivery, ordered)
- Use **unreliable UDP for state** (latest-wins, low latency)

### Idempotency

**Idempotent Messages** (safe to replay):
- WORLD_STATE: Always represents current state
- ENEMY_DEATH: Keyed by enemy_id (already dead = no-op)
- HEARTBEAT: Stateless acknowledgment

**Non-Idempotent Messages** (must deduplicate):
- PLAYER_INPUT: Use sequence_number per player
- ENEMY_SPAWN: Use enemy_id (reject duplicates)
- DAMAGE_EVENT: Track processed event_ids

**Deduplication Strategy**:
```cpp
// Per-player input deduplication
if (input.sequence_number <= player.last_processed_sequence) {
    // Reject duplicate or out-of-order
    return;
}
player.last_processed_sequence = input.sequence_number;

// Per-enemy spawn deduplication
if (spawned_enemies.contains(spawn.enemy_id)) {
    // Already spawned, ignore
    return;
}
spawned_enemies.insert(spawn.enemy_id);
```

### Join-In-Progress Rules

**Lobby Join** (LOBBY_WAIT state):
- Player can join freely
- Receives current player list
- No state synchronization needed

**Mid-Wave Join** (WAVE_ACTIVE state):
- **Allowed**: Player can join during active wave
- **State Sync**: Server sends full WORLD_STATE snapshot
- **Catch-up**: Client reconstructs all active enemies from snapshot
- **Limitation**: Cannot join during FINALE_SEQUENCE (spectate only)

**State Sync Protocol**:
1. Client sends PLAYER_JOIN request
2. Server validates (max players, not finale)
3. Server sends WORLD_STATE snapshot (full state)
4. Server sends all active ENEMY_SPAWN events (last 60s)
5. Client reconstructs game state
6. Server broadcasts PLAYER_JOINED event to all clients
7. Client begins normal update loop

**Spectator Mode** (join during finale):
- Client receives read-only WORLD_STATE
- No input accepted
- Can participate after retry

---

## Desync Detection and Recovery

### Desync Detection

**Hash-Based Detection**:
```cpp
// Server-side per-frame hash
uint32_t server_state_hash = ComputeStateHash({
    frame_number,
    battleship_health,
    enemy_positions,
    enemy_health,
    player_scores
});

// Broadcast hash every 10 frames (0.5s)
SendHashCheckpoint(frame_number, server_state_hash);
```

```cpp
// Client-side validation
void OnHashCheckpoint(uint32_t frame, uint32_t server_hash) {
    uint32_t client_hash = ComputeStateHash(frame);
    if (client_hash != server_hash) {
        ReportDesync(frame, client_hash, server_hash);
        RequestStateSnapshot(frame);
    }
}
```

**Critical State Elements**:
- Enemy count and IDs
- Enemy positions (tolerance: ±0.5 units)
- Enemy health values
- Battleship health
- Current wave number

**Detection Frequency**: Every 10 frames (0.5s at 20 Hz simulation)

### Desync Recovery

**Soft Recovery** (minor position drift):
1. Client receives corrective WORLD_STATE
2. Smoothly interpolate entities to correct positions over 1 second
3. Continue simulation with corrections applied

**Hard Recovery** (critical state mismatch):
1. Client detects severe desync (>5 units position error)
2. Pause local simulation
3. Request full state snapshot from server
4. Destroy all local entities
5. Reconstruct state from snapshot
6. Resume simulation with fresh state
7. Display brief "Synchronizing..." UI overlay

**Desync Logging**:
```json
{
  "event": "desync_detected",
  "timestamp": "2025-01-15T10:23:45.123Z",
  "frame_number": 1234,
  "player_id": 42,
  "client_hash": "0xABCD1234",
  "server_hash": "0xABCD5678",
  "drift_magnitude": 8.5,
  "recovery_method": "hard"
}
```

### Prevention Strategies

**Deterministic Simulation**:
- Fixed-timestep physics (50ms per frame)
- Deterministic random number generation (seeded per spawn)
- No floating-point accumulation errors (use integer HP)

**Input Synchronization**:
- Server broadcasts all player inputs to all clients
- Clients simulate same inputs in same order
- Server validates final state

**Latency Compensation**:
- Client-side prediction for local player
- Server reconciliation for authoritative state
- No prediction for other players (display server state)

---

## Authoritative Server Timing

### Fixed-Step Scheduling

**Simulation Rate**: 20 Hz (50ms per frame)

**Tick Pipeline**:
```
[Frame N Start - 0ms]
  ↓
  1. Process Inputs (0-5ms)
     - Receive all player inputs
     - Queue for processing
  ↓
  2. Simulate Physics (5-25ms)
     - Update enemy positions
     - Detect collisions
     - Apply damage
  ↓
  3. Game Logic (25-35ms)
     - Check wave completion
     - Spawn new enemies
     - Validate win/loss
  ↓
  4. State Broadcast (35-45ms)
     - Serialize WORLD_STATE
     - Send to all clients
  ↓
  5. Idle/Catch-up (45-50ms)
     - Wait for next tick
[Frame N+1 Start - 50ms]
```

**Timing Guarantees**:
- **Fixed 50ms tick**: Always advance simulation by exactly 50ms
- **Late frames**: If processing exceeds 50ms, log warning but do not skip tick
- **Catchup limit**: If >3 ticks behind, log critical error and throttle

### Clock Synchronization

**NTP-Style Sync**:
1. Client sends SYNC_REQUEST with client_timestamp_ms
2. Server responds with server_timestamp_ms
3. Client computes round-trip time (RTT)
4. Client estimates offset: `offset = (server_time - client_time) - RTT/2`
5. Client applies offset to all timestamps

**Sync Frequency**: Every 10 seconds (or on desync detection)

**Timestamp Wrapping**:
- Use 16-bit timestamps (0-65535 ms, wraps every 65.5s)
- Handle wrapping: `delta = (new_time - old_time) & 0xFFFF`

### Latency Compensation

**Client-Side Prediction**:
```cpp
// Client predicts own actions immediately
void Client::FireWeapon() {
    // Optimistic: play VFX/SFX immediately
    PlayFireEffect();
    
    // Send input to server
    SendPlayerInput(INPUT_FIRE, aim_direction);
    
    // Predict hit (tentative)
    PredictProjectileHit();
}

// Server validates and broadcasts
void Server::ProcessPlayerInput(PlayerInput input) {
    // Simulate on server timeline
    bool hit = SimulateProjectile(input.aim_direction);
    
    // Broadcast authoritative result
    if (hit) {
        BroadcastDamageEvent(enemy_id, damage);
    }
}

// Client reconciles
void Client::OnDamageEvent(DamageEvent event) {
    // If prediction was wrong, correct it
    if (!predicted_hits.contains(event.enemy_id)) {
        // Missed prediction - show delayed effect
        PlayDelayedHitEffect(event.enemy_id);
    }
}
```

**Rewind-Replay** (for hit validation):
- Server stores last 500ms of entity positions
- When validating hit, rewind to client's timestamp
- Simulate hit detection at that moment
- Apply damage in current frame

---

## Finale Timeline (Superweapon Sequence)

### Trigger Conditions

**Finale triggers when**:
- Wave 10 completes successfully (all enemies defeated)
- Battleship health > 0
- At least 1 player connected

**Finale does NOT trigger if**:
- Battleship destroyed before wave 10 completion
- Host disconnects during wave 10

### Superweapon Sequence (20 seconds)

```
[T+0s]   FINALE_TRIGGER state entered
         - HUD displays "SUPERWEAPON CHARGING"
         - Camera pans to battleship
         - Dramatic music starts

[T+3s]   Charging VFX intensifies
         - Energy particles from battleship
         - Screen shake effect (low intensity)

[T+5s]   FINALE_SEQUENCE state entered
         - "SUPERWEAPON ARMED" notification
         - Camera follows superweapon aiming

[T+7s]   Warning klaxon
         - All players see targeting reticle
         - Enemy swarm appears (50 UFOs)

[T+10s]  FIRE COMMAND
         - Host presses "FIRE" button (or auto-fires)
         - Massive beam VFX from battleship
         - Screen shake (high intensity)

[T+12s]  Impact
         - Beam hits enemy swarm
         - Explosion VFX (large particle burst)
         - All enemies destroyed instantly

[T+15s]  Aftermath
         - Dust particles settle
         - Victory music swells

[T+18s]  Score tallying
         - Display final scores
         - Show player rankings

[T+20s]  VICTORY state entered
         - Victory screen displayed
         - Options: Retry, Main Menu, Quit
```

### Finale Triggers

| Trigger Event        | Timing | Action                            |
|----------------------|--------|-----------------------------------|
| Wave 10 Complete     | T+0s   | Enter FINALE_TRIGGER state        |
| Charge Complete      | T+5s   | Enter FINALE_SEQUENCE state       |
| Swarm Spawn          | T+7s   | Spawn 50 enemies (visual only)   |
| Fire Command         | T+10s  | Trigger superweapon beam          |
| Impact               | T+12s  | Destroy all enemies, play VFX     |
| Score Tally          | T+18s  | Calculate final scores            |
| Victory Screen       | T+20s  | Enter VICTORY state               |

### Victory/Defeat Conditions

**VICTORY**:
- Finale sequence completes successfully
- Battleship health > 0 at T+20s
- All players receive victory rewards

**DEFEAT (during finale)**:
- Battleship health reaches 0 during finale sequence
- Immediately abort finale, enter DEFEAT state
- Display defeat screen with final scores

**DEFEAT (before finale)**:
- Battleship health reaches 0 during any wave
- Game ends immediately, no finale

### Retry Logic

**From VICTORY Screen**:
1. Host selects "Retry"
2. Server broadcasts GAME_END (retry flag)
3. All clients return to LOBBY_WAIT
4. Scores reset, difficulty retained

**From DEFEAT Screen**:
1. Host selects "Retry" or "Retry Lower Difficulty"
2. Server broadcasts GAME_END (retry flag, difficulty)
3. All clients return to LOBBY_WAIT
4. If difficulty lowered, server adjusts parameters

**Retry Limits**:
- No limit on retries
- Each retry = new game session (fresh state)

---

## Performance Budgets

### CPU Budget (per frame, 50ms target)

| System                  | Budget | Target | Notes                          |
|-------------------------|--------|--------|--------------------------------|
| Game Logic              | 15ms   | 10ms   | Wave manager, game state       |
| Physics & Collision     | 10ms   | 7ms    | Enemy movement, hit detection  |
| Networking              | 8ms    | 5ms    | Serialize/deserialize, send    |
| Audio                   | 5ms    | 3ms    | Sound effects, music           |
| UI Rendering            | 7ms    | 5ms    | HUD updates, score display     |
| AI (Enemy Behavior)     | 5ms    | 3ms    | Pathfinding, targeting         |
| **Total Frame Budget**  | 50ms   | 33ms   | 20 Hz simulation, 30 Hz ideal  |

**Optimization Strategies**:
- Object pooling for enemies (max 50 active)
- Spatial partitioning for collision detection (octree)
- LOD system for distant enemies (reduce poly count)
- Batch audio processing (process N sounds per frame)

### GPU Budget (60 FPS target on AR glasses)

| System                  | Draw Calls | Triangles | Texture Memory | Notes               |
|-------------------------|------------|-----------|----------------|---------------------|
| Battleship (Hikari)     | 5          | 8,000     | 4 MB           | LOD0 only           |
| Enemies (50 max)        | 50         | 50,000    | 8 MB           | Instanced rendering |
| Projectiles (200 max)   | 10         | 4,000     | 1 MB           | Instanced, billboards |
| VFX (Particles)         | 20         | 10,000    | 2 MB           | Particle systems    |
| UI (HUD)                | 10         | 1,000     | 2 MB           | 2D sprites          |
| Environment (Skybox)    | 1          | 12        | 4 MB           | Cubemap             |
| **Total**               | **96**     | **73,012**| **21 MB**      | Target: <100 draws  |

**GPU Optimization**:
- Instanced rendering for enemies (1 draw call per type)
- Billboard sprites for projectiles (GPU-side quad generation)
- Shared material atlases (reduce texture swaps)
- Frustum culling (cull off-screen enemies)

### Memory Budget

| Category                | Budget   | Notes                              |
|-------------------------|----------|------------------------------------|
| Game Logic              | 50 MB    | State, entities, pooling           |
| Textures                | 30 MB    | Compressed (ETC2/ASTC)             |
| Meshes                  | 20 MB    | Compressed vertex data             |
| Audio                   | 15 MB    | Compressed (Vorbis)                |
| Networking              | 5 MB     | Buffers, packet queues             |
| UI                      | 10 MB    | HUD textures, fonts                |
| **Total**               | **130 MB** | Target: <150 MB runtime          |

**Memory Optimization**:
- Streaming audio (don't load all at once)
- Texture compression (ETC2 on Android, ASTC on iOS)
- Aggressive object pooling (no runtime allocations)

### Platform Targets

| Platform               | Min FPS | Target FPS | Resolution | Notes                    |
|------------------------|---------|------------|------------|--------------------------|
| **AR Glasses (MiRZA)** | 30      | 60         | 1920x1080  | Primary target           |
| **Host (Android)**     | 30      | 60         | 1920x1080  | Mid-range devices        |
| **Host (iOS)**         | 30      | 60         | 2532x1170  | iPhone 12+               |
| **Host (PC)**          | 60      | 120        | 1920x1080  | High-end PC              |
| **Host (Console)**     | 30      | 60         | 1920x1080  | PS5, Xbox Series X       |

**Minimum Specs (Android)**:
- **CPU**: Snapdragon 865 or equivalent
- **GPU**: Adreno 650 or equivalent
- **RAM**: 6 GB
- **OS**: Android 10+

**Minimum Specs (iOS)**:
- **Device**: iPhone 12 or later
- **OS**: iOS 15+

### LOD Recommendations

#### Hikari Battleship
- **LOD0** (0-20m): 8,000 tris, 2K textures
- **LOD1** (20-50m): 4,000 tris, 1K textures
- **LOD2** (50m+): 2,000 tris, 512px textures

#### UFO Enemies
- **LOD0** (0-15m): 1,000 tris per enemy
- **LOD1** (15-40m): 500 tris per enemy
- **LOD2** (40m+): 200 tris, billboarded sprite

**LOD Transition**:
- Smooth cross-fade over 2m distance
- Hysteresis to prevent popping (±1m)

**Distance-Based Culling**:
- Enemies beyond 60m: cull completely
- Projectiles beyond 80m: cull

---

## References

- **Implementation**: [Issue #185](https://github.com/BladeWireless/blade-sdk/issues/185)
- **Asset Pipeline**: [Issue #198](https://github.com/BladeWireless/blade-sdk/issues/198), [docs/asset_pipeline_overview.md](../../asset_pipeline_overview.md)
- **Telemetry**: [Issue #199](https://github.com/BladeWireless/blade-sdk/issues/199), [telemetry.md](./telemetry.md)
- **Localization**: [Issue #200](https://github.com/BladeWireless/blade-sdk/issues/200)
- **EPIC PRs**: [#207](https://github.com/BladeWireless/blade-sdk/pull/207), [#208](https://github.com/BladeWireless/blade-sdk/pull/208)
- **Assets Spec**: [assets.md](./assets.md)
- **Wiki Design Page**: [docs/wiki/Space-Battleship-Design.md](../../wiki/Space-Battleship-Design.md)

---

**Document Version**: 1.0  
**Last Updated**: 2025-01-15  
**Status**: Ready for Implementation
