using UnityEngine;

namespace BladeWireless.SpaceBattleship.Audio
{
    /// <summary>
    /// Audio controller for Space Battleship Defense demo.
    /// Manages background music (looping) and sound effects (one-shot).
    /// Part of Space Battleship Defense audio asset update.
    /// </summary>
    public class SpaceBattleshipAudioController : MonoBehaviour
    {
        [Header("Audio Sources")]
        [Tooltip("Audio source for background music (looping)")]
        [SerializeField] private AudioSource bgmSource;

        [Tooltip("Audio source for sound effects (one-shot)")]
        [SerializeField] private AudioSource sfxSource;

        [Header("Background Music Clips")]
        [Tooltip("Lobby background music")]
        [SerializeField] private AudioClip bgmLobby;

        [Tooltip("Wave background music")]
        [SerializeField] private AudioClip bgmWave;

        [Tooltip("Finale background music")]
        [SerializeField] private AudioClip bgmFinale;

        [Header("Sound Effect Clips")]
        [Tooltip("Laser fire sound effect")]
        [SerializeField] private AudioClip sfxLaser;

        [Tooltip("Superweapon sound effect")]
        [SerializeField] private AudioClip sfxSuperweapon;

        void Awake()
        {
            // Initialize audio sources if not assigned
            if (bgmSource == null)
            {
                bgmSource = gameObject.AddComponent<AudioSource>();
                bgmSource.loop = true;
                bgmSource.playOnAwake = false;
            }
            else
            {
                // Ensure BGM source is configured for looping
                bgmSource.loop = true;
            }

            if (sfxSource == null)
            {
                sfxSource = gameObject.AddComponent<AudioSource>();
                sfxSource.loop = false;
                sfxSource.playOnAwake = false;
            }
            else
            {
                // Ensure SFX source is configured for one-shot
                sfxSource.loop = false;
            }

            // Attempt to load clips from Resources if not assigned
            LoadClipsFromResources();
        }

        /// <summary>
        /// Attempt to load audio clips from Resources folder if not assigned.
        /// </summary>
        private void LoadClipsFromResources()
        {
            if (bgmLobby == null)
            {
                bgmLobby = Resources.Load<AudioClip>("SpaceBattleshipDefense/Audio/bgm_lobby");
            }

            if (bgmWave == null)
            {
                bgmWave = Resources.Load<AudioClip>("SpaceBattleshipDefense/Audio/bgm_wave");
            }

            if (bgmFinale == null)
            {
                bgmFinale = Resources.Load<AudioClip>("SpaceBattleshipDefense/Audio/bgm_finale");
            }

            if (sfxLaser == null)
            {
                sfxLaser = Resources.Load<AudioClip>("SpaceBattleshipDefense/Audio/SFX/sfx_laser");
            }

            if (sfxSuperweapon == null)
            {
                sfxSuperweapon = Resources.Load<AudioClip>("SpaceBattleshipDefense/Audio/SFX/sfx_superweapon");
            }
        }

        #region BGM Playback Methods

        /// <summary>
        /// Play lobby background music.
        /// </summary>
        public void PlayLobbyBgm()
        {
            PlayBgm(bgmLobby, "Lobby");
        }

        /// <summary>
        /// Play wave background music.
        /// </summary>
        public void PlayWaveBgm()
        {
            PlayBgm(bgmWave, "Wave");
        }

        /// <summary>
        /// Play finale background music.
        /// </summary>
        public void PlayFinaleBgm()
        {
            PlayBgm(bgmFinale, "Finale");
        }

        /// <summary>
        /// Stop background music.
        /// </summary>
        public void StopBgm()
        {
            if (bgmSource != null)
            {
                bgmSource.Stop();
            }
        }

        /// <summary>
        /// Internal method to play BGM clip.
        /// </summary>
        private void PlayBgm(AudioClip clip, string context)
        {
            if (bgmSource == null)
            {
                Debug.LogWarning($"[SpaceBattleshipAudioController] BGM source not assigned, cannot play {context} BGM");
                return;
            }

            if (clip == null)
            {
                Debug.LogWarning($"[SpaceBattleshipAudioController] {context} BGM clip not assigned");
                return;
            }

            bgmSource.clip = clip;
            bgmSource.Play();
            Debug.Log($"[SpaceBattleshipAudioController] Playing {context} BGM");
        }

        #endregion

        #region SFX Playback Methods

        /// <summary>
        /// Play laser fire sound effect.
        /// </summary>
        public void PlaySfxLaser()
        {
            PlaySfx(sfxLaser, "Laser");
        }

        /// <summary>
        /// Play superweapon sound effect.
        /// </summary>
        public void PlaySfxSuperweapon()
        {
            PlaySfx(sfxSuperweapon, "Superweapon");
        }

        /// <summary>
        /// Internal method to play SFX clip.
        /// </summary>
        private void PlaySfx(AudioClip clip, string context)
        {
            if (sfxSource == null)
            {
                Debug.LogWarning($"[SpaceBattleshipAudioController] SFX source not assigned, cannot play {context} SFX");
                return;
            }

            if (clip == null)
            {
                Debug.LogWarning($"[SpaceBattleshipAudioController] {context} SFX clip not assigned");
                return;
            }

            sfxSource.PlayOneShot(clip);
            Debug.Log($"[SpaceBattleshipAudioController] Playing {context} SFX");
        }

        #endregion
    }
}
