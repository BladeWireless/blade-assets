# Space Battleship Defense - Scripts

This directory contains C# scripts for the Space Battleship Defense demo.

## SpaceBattleshipAudioController

Audio management controller for background music and sound effects.

### Usage

1. **Add to Scene**
   ```
   - Create an empty GameObject (e.g., "AudioManager")
   - Add SpaceBattleshipAudioController component
   ```

2. **Configure in Inspector**
   - Assign audio clips to serialized fields:
     - BGM Lobby, Wave, Finale (.ogg files)
     - SFX Laser, Superweapon (.ogg files)
   - Optionally assign custom AudioSource components for BGM and SFX
   - If AudioSources are not assigned, they will be created automatically

3. **Call from Code**
   ```csharp
   using BladeWireless.SpaceBattleship.Audio;

   // Get reference
   SpaceBattleshipAudioController audioController = 
       FindObjectOfType<SpaceBattleshipAudioController>();

   // Play background music (loops)
   audioController.PlayLobbyBgm();
   audioController.PlayWaveBgm();
   audioController.PlayFinaleBgm();
   audioController.StopBgm();

   // Play sound effects (one-shot)
   audioController.PlaySfxLaser();
   audioController.PlaySfxSuperweapon();
   ```

### Features

- **Automatic AudioSource Setup**: Creates BGM and SFX AudioSources if not assigned
- **Looping BGM**: BGM tracks loop automatically
- **One-Shot SFX**: Sound effects play once using PlayOneShot
- **Resources Fallback**: Attempts to load clips from Resources folder if not assigned
- **Debug Logging**: Logs playback events and warnings for missing clips

### Integration Example

```csharp
public class GameStateManager : MonoBehaviour
{
    private SpaceBattleshipAudioController audioController;

    void Start()
    {
        audioController = FindObjectOfType<SpaceBattleshipAudioController>();
    }

    void OnEnterLobby()
    {
        audioController.PlayLobbyBgm();
    }

    void OnWaveStart()
    {
        audioController.PlayWaveBgm();
    }

    void OnFinaleStart()
    {
        audioController.PlayFinaleBgm();
    }

    void OnPlayerFireLaser()
    {
        audioController.PlaySfxLaser();
    }

    void OnSuperweaponActivated()
    {
        audioController.PlaySfxSuperweapon();
    }
}
```

### Expected Audio File Paths

When using Resources.Load fallback:
- `Resources/SpaceBattleshipDefense/Audio/bgm_lobby.ogg`
- `Resources/SpaceBattleshipDefense/Audio/bgm_wave.ogg`
- `Resources/SpaceBattleshipDefense/Audio/bgm_finale.ogg`
- `Resources/SpaceBattleshipDefense/Audio/SFX/sfx_laser.ogg`
- `Resources/SpaceBattleshipDefense/Audio/SFX/sfx_superweapon.ogg`

Or assign directly in the Inspector from any location in the project.
