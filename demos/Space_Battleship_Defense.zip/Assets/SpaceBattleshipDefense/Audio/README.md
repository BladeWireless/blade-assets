# Space Battleship Defense - Audio Assets

This directory contains audio assets for the Space Battleship Defense demo.

## Expected Audio Files

### Background Music (BGM)
- `bgm_lobby.ogg` - Lobby/menu background music (looping)
- `bgm_wave.ogg` - Wave gameplay background music (looping)
- `bgm_finale.ogg` - Finale sequence background music (looping)

### Sound Effects (SFX)
Located in `SFX/` subdirectory:
- `sfx_laser.ogg` - Laser fire sound effect (one-shot)
- `sfx_superweapon.ogg` - Superweapon activation sound effect (one-shot)

## Format
- **Container**: Ogg Vorbis (.ogg)
- **Sample Rate**: 48 kHz recommended
- **Channels**: Stereo for BGM, Mono or Stereo for SFX
- **Bitrate**: Variable (quality 5-7 recommended)

## Integration
Audio files are referenced by `SpaceBattleshipAudioController.cs` in the Scripts directory.
The controller supports both direct assignment via Unity Inspector and fallback loading from Resources folder.

## Placeholder Files
`.placeholder` files indicate where actual audio assets should be placed.
These placeholders are temporary and should be replaced with actual .ogg audio files.
